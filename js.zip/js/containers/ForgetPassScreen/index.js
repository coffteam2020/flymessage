import React, { useEffect, useState } from "react";
import { StatusBar, View, SafeAreaView } from "react-native";
import { styles } from "./style";
import { withTheme } from "react-native-paper";
import TextNormal from "../../shared/components/Text/TextNormal";
import { containerStyle } from "../../themes/styles";
import { useTranslation } from 'react-i18next';
import Back from "../../shared/components/Icons/Back";
import { textStyleDefaultHeader } from "../../themes/text";
import Check from "../../shared/components/Icons/Check";
import TextInputFlat from "../../shared/components/TextInput/TextInputFlat";
import { colors } from "../../shared/utils/colors/colors";
import GradientButton from "../../shared/components/Buttons/GradientButton";
import Validator from "../../shared/utils/validator/Validator";
import { ToastHelper } from "../../shared/components/ToastHelper";
import Loading from "../../shared/components/Loading";
import { NavigationService } from "../../navigation";
import Route, { ScreenNames } from "../../route/ScreenNames";


const ForgetPassScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	const [email, setEmail] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [valid, setValid] = useState(false);
	const onEmailChange = text => {
		setEmail(text);
		if (Validator.checkEmail(text)) {
			setValid(true);
		} else {
			setValid(false);
		}
	}
	const onSendEmail = () => {
		setIsLoading(true);
		if (!valid) {
			ToastHelper.showError(t("error.notValid.email"))
			setIsLoading(false);
		} else {
			setIsLoading(false);
			ToastHelper.showSuccess(t("developing.name"))
			NavigationService.navigate(Route.ScreenNames.ResetPassScreen);
		}
	}
	useEffect(() => {

	}, [])

	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<View style={styles.content}>
					<Back props={props} onPress={() => NavigationService.navigate(ScreenNames.LoginScreen)} />
					<View style={styles.container}>
						<TextNormal props={props} text={t("forget.name")} style={[textStyleDefaultHeader, styles.motto]} />
						<TextNormal numberOfLines={2} props={props} text={t("forget.motto")} style={styles.mottoEmail} />
						<TextInputFlat value={email} onChangeText={(text) => onEmailChange(text)} text={t("login.email")} props={props} hasRightIco={valid} ico={<Check color={colors.green} />} />
						<GradientButton onPress={() => onSendEmail()} text={t("forget.sendEmail")} style={styles.button} />
					</View>
				</View>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>

		</View>
	);
}

export default withTheme(ForgetPassScreen);
