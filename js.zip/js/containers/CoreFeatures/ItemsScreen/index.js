import {useObserver} from 'mobx-react';
import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {SafeAreaView, ScrollView, StatusBar, TouchableOpacity, View} from 'react-native';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {colors} from '../../../shared/utils/colors/colors';
import {ScreenWidth, ScreenHeight} from '../../../shared/utils/dimension/Divices';
import {useStores} from '../../../store/useStore';
import {containerStyle} from '../../../themes/styles';
import {styles} from './style';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import LogManager from '../../../shared/utils/logging/LogManager';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import AxiosFetcher from '../../../api/AxiosFetch';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import Loading from '../../../shared/components/Loading';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import Constant from '../../../shared/utils/constant/Constant';
import Empty from '../../../shared/components/Empty';

const ItemsScreen = (props) => {
	const {colorsApp} = props.theme;
	const [currentIndex, setCurrentIndex] = useState(0);
	const [isLoading, setIsLoading] = useState(false);
	const {t} = useTranslation();
	const {userStore} = useStores();

	useEffect(() => {
		getItems();
	}, []);

	const getItems = async () => {
		const token = await IALocalStorage.getTokenUserInfo();
		console.log(LogManager.parseJsonObjectToJsonString(token));
		setIsLoading(true);
		const userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: `/api/person/${userInfoId?.id}/itemsuser`,
			hasToken: true,
		})
			.then(async val => {
				setIsLoading(false);
				userStore.setItemsBag(val || []);
			})
			.catch(() => {
				setIsLoading(false);
			});
	};

	const renderTopHeader = () => {
		return (
			<HeaderWithBackBtn props={props} title="Your items bag" />
		);
	};

	const renderItems = () => {
		const items = userStore?.itemsBag?.slice().filter(item => !item?.salable).filter(item => item?.quantity>0) || [];
		if (items.length === 0) {
			return <Empty />;
		}
		return (
			items.map(item => {
				const {itemUrl, title, quantity} = item;
				return (
					<>
						{quantity > 0 && renderItem(itemUrl, title, `${quantity}`, quantity)}
					</>
				);
			}));
	};
	const renderItemsSpecial = () => {
		const items = userStore?.itemsBag && userStore?.itemsBag?.slice().filter(item => item?.salable).filter(item => item?.quantity>0) || [];
		if (items.length === 0) {
			return <Empty />;
		}
		return (
			items.map(item => {
				const {itemUrl, title, quantity} = item;
				return (
					<>
						{quantity > 0 && renderItem(itemUrl, title, `${quantity}`, quantity)}
					</>
				);
			}));
	};

	const renderItem = (ico, name, price, desc, onPress) => {
		return (
			<TouchableOpacity onPress={onPress} style={[containerStyle.horContainer, styles.item]}>
				<View
					style={[containerStyle.horContainer, {
						paddingStart: 40,
						paddingEnd: 40,
						alignSelf: 'flex-start',
						alignItems: 'flex-start'
					}]}>
					<View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingLeft: 30}}>
						<ImageAvtRectRounded
							style={[containerStyle.avatarRectRoundedStoreDefault]}
							uri={ico || Constant.MOCKING_DATA.PLACE_HOLDER} />
						<View style={{marginLeft: 30}}>
							<TextNormal props={props} text={name} style={[styles.textDefaultHeader]} />
							<TextNormal props={props} text={''} style={[containerStyle.textContentSmall]} />
							<TextNormal numberOfLines={5} props={props} text={`Quantity:  ${desc}`}
								style={[styles.textContentSmall, {width: ScreenWidth - 100}]} />
						</View>
					</View>
					
				</View>
			</TouchableOpacity>
		);
	};

	const renderTabbar = () => {
		return (
			<View style={[containerStyle.horContainer, containerStyle.shadow, {
				height: ScreenHeight / 10,
				backgroundColor: colors.whiteBackground,
				width: ScreenWidth,
			}]}>
				<TouchableOpacity onPress={() => {
					setCurrentIndex(0);
				}}
				style={[styles.btn, currentIndex !== 0 ? {backgroundColor: colors.gray} : containerStyle.defaultBackground]}>
					<TextNormal text="Feature items" style={{color: currentIndex === 0 ? 'white' : 'black'}} />
				</TouchableOpacity>
				<TouchableOpacity onPress={() => {
					setCurrentIndex(1);
				}}
				style={[styles.btn, currentIndex !== 1 ? {backgroundColor: colors.gray} : containerStyle.defaultBackground]}>
					<TextNormal text="Special items" style={{color: currentIndex === 1 ? 'white' : 'black'}} />
				</TouchableOpacity>
			</View>
		);
	};
	return useObserver(() => (
		<View style={[containerStyle.default, containerStyle.defaultBackgroundSecond]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderTopHeader()}
				<View style={styles.content}>
					{renderTabbar()}
					<ScrollView contentContainerStyle={{paddingBottom: 100}}>
						{currentIndex === 0 ? renderItems() : renderItemsSpecial()}
					</ScrollView>
				</View>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	));
};

export default withTheme(ItemsScreen);
