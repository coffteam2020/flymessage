export { default } from "./Album";
