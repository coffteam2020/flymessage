import { useObserver } from 'mobx-react';
import React, { useState } from 'react';
import { ScrollView, StatusBar, View } from 'react-native';
import { withTheme } from 'react-native-paper';
import { containerStyle } from '../../../themes/styles';
import { styles } from './style';
import TrackPlayer from 'react-native-track-player';
import Album from './Album';
import BottomTab from './BottomTab';
import Back from '../../../shared/components/Icons/Back';
import { useNavigationParam } from 'react-navigation-hooks';
import LogManager from '../../../shared/utils/logging/LogManager';
import { useStores } from '../../../store/useStore';
import Player from './Player';
import TextNormal from '../../../shared/components/Text/TextNormal';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
const SpotifyScreen = (props) => {
	const songs = useNavigationParam('songs');
	const [song, setSong] = useState(songs);
	const { userStore } = useStores();
	const TRACKS = [
		{
			title: 'Stressed Out',
			artist: 'Twenty One Pilots',
			albumArtUrl: "http://36.media.tumblr.com/14e9a12cd4dca7a3c3c4fe178b607d27/tumblr_nlott6SmIh1ta3rfmo1_1280.jpg",
			audioUrl: "http://dl.fazmusics.in/Ali/music/aban/hot%20100%20.7%20nov%202015(128)/Twenty%20One%20Pilots%20-%20Stressed%20Out.mp3",
		},
		{
			title: 'Love Yourself',
			artist: 'Justin Bieber',
			albumArtUrl: "http://arrestedmotion.com/wp-content/uploads/2015/10/JB_Purpose-digital-deluxe-album-cover_lr.jpg",
			audioUrl: 'http://srv2.dnupload.com/Music/Album/Justin%20Bieber%20-%20Purpose%20(Deluxe%20Version)%20(320)/Justin%20Bieber%20-%20Purpose%20(Deluxe%20Version)%20128/05%20Love%20Yourself.mp3',
		},
		{
			title: 'Hotline Bling',
			artist: 'Drake',
			albumArtUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/c9/Drake_-_Hotline_Bling.png',
			audioUrl: 'http://dl2.shirazsong.org/dl/music/94-10/CD%201%20-%20Best%20of%202015%20-%20Top%20Downloads/03.%20Drake%20-%20Hotline%20Bling%20.mp3',
		},
	];

	React.useEffect(() => {
		TrackPlayer.stop();
		userStore.setSongs(songs?.tracks || []);
		// userStore.setCurrentSongs(songs?.tracks[0] || null);
		userStore.setCurrentIndexSongs(0);
		IALocalStorage.getSongBlocked().then(val => {
			if (val) {
				for (let i = 0; i < val?.length; i++) {
					for (let j = 0; j < songs.tracks.length; j++) {
						if (val[i].audioUrl === songs.tracks[j].audioUrl) {
							setSong(song.tracks.filter(item => item.audioUrl !==songs.tracks[j].audioUrl));
						}
					}
				}
			}
		})
	}, [props?.navigation]);


	return useObserver(() => (
		<View style={[containerStyle.default, containerStyle.defaultBackgroundSecond, styles.mainContainer]}>
			<View style={{ position: 'absolute', top: 40, left: 20, zIndex: 10 }}>
				<Back props={props} />
			</View>
			<>
				<Player tracks={song?.tracks} />
			</>
		</View>
	));
};

export default withTheme(SpotifyScreen);

