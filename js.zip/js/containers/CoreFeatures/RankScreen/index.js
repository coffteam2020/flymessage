import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView} from 'react-native';
import {styles as style} from './style';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {NavigationService} from '../../../navigation';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {ImageBackground} from 'react-native';
import {images} from '../../../../assets';
import Back from '../../../shared/components/Icons/Back';
import {colors} from '../../../shared/utils/colors/colors';
import {TouchableOpacity} from 'react-native-gesture-handler';
import icons from '../../../shared/utils/icons/icons';
import {SPACINGS} from '../../../themes';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import AxiosFetcher from '../../../api/AxiosFetch';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import FastImage from 'react-native-fast-image';
import {ScreenWidth} from '../../../shared/utils/dimension/Divices';
import Constant from '../../../shared/utils/constant/Constant';

const ABOUT = `Meet, connect, chat and learn with friends all over the world, understand cultures and languages ​​through fly messages, audio channels and video streams.
In modern society, the application to connect with friends has become familiar and as part of your daily life. We created this application with nostalgic and dreamy ideas.
A letter folded in the form of an airplane and dropped into the vast sky carrying your message. It will randomly come to a friend you never knew and that's where a friendship begins.
We offer fly message feature - send random message.
We offer pigeon mailing - send messages with destination.
We bring radio - listen to the stories of friends.
We offer video stream - livestream and room interaction.
And other interesting features waiting for you to discover ...`;
const RankScreen = (props) => {
	const {colorsApp} = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const [user, setUser] = useState([]);
	const [me, setMe] = useState([]);
	const [indexme, setIndex] = useState([]);
	useEffect(() => {
		getUsers();
	}, []);
	const getUsers = async () => {
		let userInfo = await IALocalStorage.getDetailUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			url: '/api/person/allWithPagination?limit=1000000&offset=0&sortBy=ranking',
			data: undefined,
			hasToken: true,
		}).then(val => {
			if (val) {
				let temp = val?.content || [];
				temp.sort((a,b) => (a.ranking > b.ranking || a.name > b.name) ? 1 : ((b.ranking > a.ranking || a.name < b.name) ? -1 : 0)); 
				setUser(temp || []);
				let a = val?.content || [];
				for (let i = 0; i < temp?.length || 0 ; i++) {
					if (temp[i].userId === userInfo?.userId) {
						setMe(a[i]);
						setIndex(i);
						break;
					}
				}
			} else {
				setUser([]);
			}
			setIsLoading(false);
		}).catch(() => {
			setIsLoading(false);
			ToastHelper.showError('Could not get list users, please try again');
		});
	};

	return (
		<View style={[containerStyle.default, {backgroundColor: colors.pinkBackground, paddingBottom: 160}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<View style={{flexDirection: 'row'}}>
					<Back props={props} onPress={() => NavigationService.goBack()} style={{marginLeft: 20, marginTop: 20}} />
					<TextNormal numberOfLines={2} props={props} text={'Leader board'} style={[containerStyle.textHeader, {marginLeft: 20, marginTop: 30, alignSelf: 'center'}]} />
				</View>
				<KeyboardAwareScrollView style={{marginTop: 20}} showsVerticalScrollIndicator={false}>
					{user?.map((item, index) => {
						return (
							<View>
								{index != 0 && <View style={{height: 2, backgroundColor: colors.gray_bg, width: '100%'}} />}
								<View style={{marginLeft: 30, flexDirection: 'row', alignItems: 'center', marginBottom: 10, marginTop: 10}}>
									<TextNormal props={props} text={`${index + 1} `}  style={[containerStyle.textDefault, {color: index < 3 ? 'red' : 'black', marginRight: 20}]}/>
									<FastImage source={{uri: item?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER}} style={{borderColor: 'white', borderWidth: 0.5, borderRadius: ScreenWidth / 10, width: ScreenWidth / 5, height: ScreenWidth / 5}} />
									<TextNormal numberOfLines={2} props={props} text={`${item?.name || 'No name'}`} style={[containerStyle.textDefault, {marginLeft: 20, width: '95%'}]} />
								</View>
							</View>
						);
					})}
				</KeyboardAwareScrollView>
				
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
			<View style={{position: 'absolute', padding: 10, paddingLeft: 30, paddingBottom: 20, bottom: 0, left: 0, backgroundColor: '#1F253D', width: ScreenWidth, flexDirection: 'row', alignItems: 'center'}}>
				<TextNormal props={props} text={`${indexme + 1}`}  style={[containerStyle.textDefault, {color: 'white', marginEnd: 20,}]}/>
				<FastImage source={{uri: me?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER}} style={{borderColor: 'white', borderWidth: 0.5, borderRadius: ScreenWidth / 14, width: ScreenWidth / 7, height: ScreenWidth / 7}} />
				<TextNormal numberOfLines={2} props={props} text={`${me?.name || 'No name'}`} style={[containerStyle.textDefault, {marginLeft: 20, width: '95%'}, {color: 'white', marginEnd: 20,}]} />
			</View>
		</View>
	);
};

export default withTheme(RankScreen);
