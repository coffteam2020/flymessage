import {useObserver} from 'mobx-react';
import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {FlatList, StatusBar, TouchableOpacity, View} from 'react-native';
import {withTheme} from 'react-native-paper';
import AxiosFetcher from '../../../../api/AxiosFetch';
import {NavigationService} from '../../../../navigation';
import {ScreenNames} from '../../../../route/ScreenNames';
import Back from '../../../../shared/components/Icons/Back';
import TextNormal from '../../../../shared/components/Text/TextNormal';
import {ToastHelper} from '../../../../shared/components/ToastHelper';
import UserItem from '../../../../shared/components/UserItem';
import {colors} from '../../../../shared/utils/colors/colors';
import icons from '../../../../shared/utils/icons/icons';
import LogManager from '../../../../shared/utils/logging/LogManager';
import {useStores} from '../../../../store/useStore';
import {SPACINGS} from '../../../../themes';
import Empty from '../../../../shared/components/Empty';
import {containerStyle} from '../../../../themes/styles';
import {styles} from './styles';
import IALocalStorage from '../../../../shared/utils/storage/IALocalStorage';

const AddFriendScreen = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const [isLoading, setIsLoading] = useState(false);
	const [friendsList, setFriendsList] = useState([]);
	const {userStore} = useStores();

	useEffect(() => {
		getFriends();
	}, []);
	const getFriends = async () => {
		const currentUser = userStore.userInfo;
		let user = await IALocalStorage.getUserInfo();
		const userId = user.id;
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			url: `/api/useraction/${userId}/friends`,
			hasToken: true,
		}).then(async val => {
			console.log(LogManager.parseJsonObjectToJsonString(val));
			setIsLoading(false);
			const friends = val.filter(res => res.userId != userId);
			setFriendsList(friends);
			userStore.setFriendList(friends);
		})
			.catch(val => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your friends, please try again');
			});
	};

	const _renderHeader = () => {
		return (
			<View style={styles.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{flexDirection: 'row'}}>
					<Back props={props} />
				</TouchableOpacity>
				<TextNormal props={props} text={t('message.addMember')} style={[containerStyle.textHeader, {color: colors.textBlue, marginLeft: 20}]} />
			</View>
		);
	};

	const renderMessageItem = (item, index) => {
		const currentUser = userStore?.userInfo;
		return (
			<UserItem
				onItemPress={async (item) => {
					let friendList = userStore.friendList || [];
					let isFriend = friendList?.filter(x => x.userId === item?.userId).length > 0;
					if (!isFriend) {
						alert('This user has been deleted, you can not chat anymore');
						return;
					}
					let blocked = userStore.blockList || [];
					for (let i = 0; i < blocked.length; i++) {
						if (blocked[i]?.userId === item?.userId || blocked[i]?.userId === item?.toUserDetail?.id) {
							alert('This user has been blocked, you can not chat anymore');
							return;
						}
					}
					// Check if name is exist
					let userInfo = await IALocalStorage.getDetailUserInfo();
					if (!userInfo?.name || userInfo?.name == '') {
						alert('You have not modified your profile, especially your name. Please edit your name in Profile');
						return;
					}
					NavigationService.navigate(ScreenNames.ChatRoomScreen, {toUserData: {
						id: item?.userId,
						name: item?.name,
						avatar: item?.avatar,
					}});
				}}
				item={item}
				index={index}
				currentUser={currentUser}
			/>
		);
	};

	const renderSeparator = () => {
		return (
			<View style={styles.separatorView}
			/>
		);
	};

	return useObserver(() => (
		<View style={[containerStyle.default, {backgroundColor: 'white'}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<View style={styles.topView} />
			<View style={styles.content}>
				{_renderHeader()}
				<TextNormal
					text={t('message.friend').toUpperCase()}
					style={[containerStyle.textNormalBlackLarge], {color: colors.textPuple, marginLeft: SPACINGS.xxLarge, marginTop: SPACINGS.large, marginBottom: SPACINGS.xLarge,}} />
				{renderSeparator()}
				{friendsList?.length === 0? 
					<Empty /> :
					<>
						<FlatList
							showsVerticalScrollIndicator={false}
							data={friendsList}
							ItemSeparatorComponent={() => renderSeparator()}
							renderItem={({item, index}) => renderMessageItem(item, index)}
							keyExtractor={(item, index) => index + ''}
							style={styles.listMessages}
						/>
						{renderSeparator()}
					</>
				}
			</View>
		</View>
	));
};

export default withTheme(AddFriendScreen);