import { firebase } from '@react-native-firebase/database';
import { useObserver } from 'mobx-react';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { StatusBar, TouchableOpacity, View, Platform, Alert } from 'react-native';
import { GiftedChat } from 'react-native-gifted-chat';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { withTheme } from 'react-native-paper';
import { useNavigationParam } from 'react-navigation-hooks';
import { FirebaseService } from '../../../../api/FirebaseService';
import { NavigationService } from '../../../../navigation';
import Back from '../../../../shared/components/Icons/Back';
import Loading from '../../../../shared/components/Loading';
import IALocalStorage from '../../../../shared/utils/storage/IALocalStorage';
import ModalActionSheet from '../../../../shared/components/Modal/ModalActionSheet';
import { ToastHelper } from '../../../../shared/components/ToastHelper';
import TopUserItem from '../../../../shared/components/TopUserItem';
import Constant from '../../../../shared/utils/constant/Constant';
import { StringHelper } from '../../../../shared/utils/helper/stringHelper';
import icons from '../../../../shared/utils/icons/icons';
import ImagePicker from 'react-native-image-picker';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SPACINGS } from '../../../../themes';
import { containerStyle } from '../../../../themes/styles';
import { styles } from './styles';
import { uploadFileToFireBase } from '../../../../shared/utils/firebaseStorageUtils';
import AxiosFetcher from '../../../../api/AxiosFetch';
import ModalPingMessage from '../../../../shared/components/Modal/ModalPinMessage';
import { ScreenWidth } from '../../../../shared/utils/dimension/Divices';
import { Base64 } from 'js-base64';
import { useStores } from '../../../../store/useStore';
import { ScreenNames } from '../../../../route/ScreenNames';

var uuid = require('uuid');
let childTemp = '';
let ownerTemp = {};
let toUserTemp = {};
const ChatRoomScreen = (props) => {
	const { colorsApp } = props.theme;
	const { userStore } = useStores();
	const { t } = useTranslation();
	const toUserData = useNavigationParam('toUserData');
	const [isLoading, setIsLoading] = useState(false);
	const [isVisible, setIsVisible] = useState(false);
	const [msg, setMsg] = useState('');
	const [messagesList, setMessagesList] = useState([]);
	const [user] = useState('');
	const [userDetail, setUserDetail] = useState('');
	const [block, setBlock] = useState(false);
	const [deleteFr, setDeleteFr] = useState(false);
	const IMAGE_CONFIG = {
		title: t('imagePicker.name'),
		cancelButtonTitle: t('common.cancel'),
		takePhotoButtonTitle: t('imagePicker.camera'),
		chooseFromLibraryButtonTitle: t('imagePicker.name'),
		storageOptions: {
			skipBackup: true,
			path: 'images',
		},
	};

	const participants = [];

	const [child, setChild] = useState('');
	// Standard data user
	const [owner, setOwner] = useState({});
	const [toUser, setToUser] = useState({});

	const notifyToUserId = (idOwner, id, nameOwner) => {
		AxiosFetcher({
			method: 'POST',
			url: '/api/useraction/' + idOwner + '/pushNotification',
			data: {
				messageType: 'NOTIFICATION',
				message: `You have a message ${nameOwner ? ('from ' + nameOwner) : ''}`,
				receiverUserId: id
			},
			hasToken: true,
		}).then(val => {
		}).catch(() => {
			ToastHelper.showError('Opps, error while trying to touch your recipient wake up but failed. Dont worry, message still has been sent successful');
		});
	};

	const standardlizeParticipiants = async () => {
		if (toUserData) {
			let toUserDetail = toUserData;
			let me = await IALocalStorage.getDetailUserInfo();
			setUserDetail(me);
			await setOwner(me);
			await setToUser(toUserDetail);

			ownerTemp = {
				id: me?.userId,
				name: me?.name,
				avatar: me?.avatar,
			};
			toUserTemp = toUserDetail;
			participants[0] = toUser?.userId;
			participants[1] = owner?.userId;

			let child = StringHelper.generateDoccumentId(me?.userId, toUserDetail?.id);
			await IALocalStorage.setRoom(toUserDetail?.name || '');
			setChild(child);
			childTemp = child;
			getMessages(child);
		}

		getMessages(child);
	};

	useEffect(() => {
		standardlizeParticipiants();
		props?.navigation.addListener('willFocus', () => {
			getInfoItem();
		});
	}, []);

	const getInfoItem = async () => {
		setIsLoading(true);
		const userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: `/api/person/${userInfoId?.id}/itemsuser`,
			hasToken: true,
		})
			.then(async val => {
				setIsLoading(false);
				userStore.setItemsBag(val || []);
			})
			.catch(() => {
				setIsLoading(false);
			});
	};

	const getMessages = async (child) => {
		if (!child) return;
		setIsLoading(true);
		await firebase.database().ref(Constant.SCHEMA.MESSAGES).child(child).on('value', snapshot => {
			setIsLoading(false);
			const data = snapshot.val();
			data && setMessagesList(data?.messages?.filter(item => item !== null));
		});
		setIsLoading(false);
	};

	const _renderHeader = () => {
		let item = toUserTemp;
		return (
			<View style={styles.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{ flexDirection: 'row' }}>
					<Back props={props} />
				</TouchableOpacity>
				<TopUserItem
					onItemPress={() => {
					}}
					item={item}
				/>
				<TouchableOpacity onPress={() => setIsVisible(true)} style={{
					width: 50,
					justifyContent: 'flex-end',
					alignItems: 'flex-end',
					alignContent: 'flex-end'
				}}>
					{icons.IC_MORE_VERT}
				</TouchableOpacity>
			</View>
		);
	};

	const onSend = (messages = [], image) => {
		if (!image && messages.length > 0 && messages[0]?.text.replace(' ', '') === '') {
			return;
		}
		messages[0] = {
			_id: uuid.v4(),
			...messages[0],
			userId: userDetail?.userId,
			timeInMillosecond: new Date().getTime(),
			createdAt: moment().utc().format('YYYY-MM-DDTHH:mm:ssZ'),
			createdOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
			modifiedOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
			text: messages[0]?.text?.trim(),
			type: 'text',
			image: image,
			toUserId: toUserTemp?.id,
			toUserDetail: {
				id: toUserTemp?._id || toUserTemp?.id,
				name: toUserTemp?.name || '',
				avatar: toUserTemp?.avatar || Constant.MOCKING_DATA.ANY_AVATAR
			},
			user: {
				name: userDetail?.name || '',
				avatar: userDetail?.avatar || Constant.MOCKING_DATA.ANY_AVATAR,
				_id: userDetail?.userId,
			}
		};

		// set state messsage list
		const msgs = GiftedChat.append(messagesList, messages);
		setMessagesList(msgs);

		// add participant if empty
		let tempParticipiant = [];

		tempParticipiant.push({
			typing: false,
			avatar: userDetail?.avatar || Constant.MOCKING_DATA.ANY_AVATAR,
			deletedAt: '',
			userId: userDetail?.userId,
			name: userDetail?.name || ''
		});
		tempParticipiant.push({
			typing: false,
			avatar: toUserTemp && toUserTemp?.avatar ? toUserTemp?.avatar : Constant.MOCKING_DATA.ANY_AVATAR,
			deletedAt: '',
			userId: toUserTemp ? toUserTemp?.id : '',
			name: toUserTemp ? toUserTemp?.name : ''
		});


		// set data send to server
		const data = {
			messages: msgs,
			participants: tempParticipiant,
			lastMessage: messages[0]
		};
		if (childTemp === '' || childTemp.includes('undefined')) {
			childTemp = StringHelper.generateDoccumentId(userDetail?.userId, toUserTemp?.id);
		}
		if (childTemp === '' || childTemp.includes('undefined')) {
			alert('Something wrong. Please go back again');
			return;
		}

		try {
			FirebaseService.pushNewItemWithChildKey(Constant.SCHEMA.MESSAGES, childTemp, data);
			notifyToUserId(userDetail?.userId, toUserTemp?.id, userDetail?.name);
			return;
		} catch (err) {
			console.log('err' + err?.message);
		}
	};

	const renderSend = (props) => {
		return (
			<TouchableOpacity style={{ marginLeft: SPACINGS.large }} onPress={() => {
				props.onSend({ text: props.text });
				setMsg('');
			}}>
				{icons.IC_SEND_MSG}
			</TouchableOpacity>
		);
	};
	const openImagePicker = () => {
		ImagePicker.launchImageLibrary(IMAGE_CONFIG, (response) => {
			// console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			} else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			} else {
				setIsLoading(true);
				Promise.resolve(uploadFileToFireBase(response, user?.id)).then(val => {

					let messages = [{
						_id: uuid.v4(),
						userId: userDetail?.userId,
						timeInMillosecond: new Date().getTime(),
						createdAt: moment().utc().format('YYYY-MM-DDTHH:mm:ssZ'),
						createdOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
						modifiedOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
						text: msg,
						image: val,
						type: 'image',
						toUserId: toUserTemp?.id,
						toUserDetail: {
							id: toUserTemp?.id,
							name: toUserTemp?.name || '',
							avatar: toUserTemp?.avatar || Constant.MOCKING_DATA.ANY_AVATAR
						},
						user: {
							name: userDetail?.name || '',
							avatar: userDetail?.avatar || Constant.MOCKING_DATA.ANY_AVATAR,
							_id: user?.userId,
						}
					}];

					onSend(messages, val);
					setIsLoading(false);
				}).catch(error => {
					console.log(error.message);
					ToastHelper.showError(t('error.common'));
					setIsLoading(false);
				});
			}
		});
	};
	const openCamera = () => {
		ImagePicker.launchCamera(IMAGE_CONFIG, (response) => {
			// console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			} else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			} else {
				setIsLoading(true);
				Promise.resolve(uploadFileToFireBase(response, user?.id)).then(val => {
					let messages = [{
						_id: uuid.v4(),
						userId: userDetail?.userId,
						timeInMillosecond: new Date().getTime(),
						createdAt: moment().utc().format('YYYY-MM-DDTHH:mm:ssZ'),
						createdOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
						modifiedOn: moment().format('YYYY-MM-DD\'T\'HH:mm:ssZ'),
						text: msg,
						image: val,
						type: 'image',
						toUserId: toUserTemp?.id,
						toUserDetail: {
							id: toUserTemp?.id,
							name: toUserTemp?.name || '',
							avatar: toUserTemp?.avatar || Constant.MOCKING_DATA.ANY_AVATAR
						},
						user: {
							name: userDetail?.name || '',
							avatar: userDetail?.avatar || Constant.MOCKING_DATA.ANY_AVATAR,
							_id: userDetail?.userId,
						}
					}];

					onSend(messages, val);
					setIsLoading(false);
				}).catch(error => {
					console.log(error.message);
					ToastHelper.showError(t('error.common'));
					setIsLoading(false);
				});
			}
		});
	};
	const renderAvatarInput = () => {
		return (
			<View style={styles.avatarSendContainer}>
				<TouchableOpacity onPress={() => checkImage()} style={{ padding: 5, zIndex: 10 }}>
					<Ionicons name='ios-images' color={containerStyle.defaultBackground.backgroundColor} size={30} />
				</TouchableOpacity>
				<TouchableOpacity style={{ marginLeft: SPACINGS.default, zIndex: 10 }} onPress={() => checkCamera()}>
					<Ionicons name='ios-camera' color={containerStyle.defaultBackground.backgroundColor} size={30} />
				</TouchableOpacity>
			</View>
		);
	};
	const blockUser = async () => {
		setIsVisible(false);
		let res = await IALocalStorage.getUserDeleted();
		res = JSON.parse(res) || [];
		res.push({
			id: toUserTemp?.id,
			user: toUserTemp,
			status: 'blocked'
		});
		await IALocalStorage.setUserDeleted(JSON.stringify(res));
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/useraction/' + userDetail?.userId + '/block/' + toUserTemp?.id,
			hasToken: true,
		})
			.then(val => {
				setIsLoading(false);
				setBlock(true);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Error while blocking this user');
			});
		setIsLoading(false);
	};
	const deleteUser = async () => {
		setIsVisible(false);
		// let res = await IALocalStorage.getUserDeleted();
		// res = JSON.parse(res) || [];
		// res.push({
		// 	id: toUserTemp?.id,
		// 	user: toUserTemp,
		// 	status: 'deleted'
		// });
		// await IALocalStorage.setUserDeleted(JSON.stringify(res));
		setIsLoading(true);
		AxiosFetcher({
			method: 'DELETE',
			data: undefined,
			url: '/api/useraction/' + userDetail?.userId + '/removeFriend/' + toUserTemp?.id,
			hasToken: true,
		})
			.then(val => {
				let curFriendList = userStore?.friendList;
				const newFriendLíst = curFriendList.filter(res => res.userId != toUserTemp?.id);
				userStore.setFriendList(newFriendLíst);
				setIsLoading(false);
				setDeleteFr(true);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Error while deleting this user');
			});
		setIsLoading(false);
	};
	const checkCamera = () => {
		let itemBags = userStore?.itemsBag || [];
		if (itemBags?.length === 0) {
			Alert.alert('Opps,', 'You have to buy item Camera to able to send image in chat', [
				{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen, { highlight: [Constant.CAMERA.itemCode] }); } },
				{ text: 'Back', onPress: () => { } },
			]);
		} else {
			let shouldMake = false;
			for (let i = 0; i < itemBags?.length; i++) {
				if (itemBags[i]?.itemCode === Constant.CAMERA.itemCode && itemBags[i]?.quantity > 0) {
					shouldMake = true;
					break;
				}
			}
			if (shouldMake) {
				openCamera();
			} else {
				Alert.alert('Opps,', 'You have to buy item Camera to able to send image in chat', [
					{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen, { highlight: [Constant.CAMERA.itemCode] }); } },
					{ text: 'Back', onPress: () => { } },
				]);
			}
		}
	};
	const checkImage = () => {
		let itemBags = userStore?.itemsBag || [];
		if (itemBags?.length === 0) {
			Alert.alert('Opps,', 'You have to buy item Image to able to send image in chat', [
				{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen, { highlight: [Constant.IMAGE.itemCode] }); } },
				{ text: 'Back', onPress: () => { } },
			]);
		} else {
			let shouldMake = false;
			for (let i = 0; i < itemBags?.length; i++) {
				if (itemBags[i]?.itemCode === Constant.IMAGE.itemCode && itemBags[i]?.quantity > 0) {
					shouldMake = true;
					break;
				}
			}
			if (shouldMake) {
				openImagePicker();
			} else {
				Alert.alert('Opps,', 'You have to buy item Image to able to send image in chat', [
					{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen, { highlight: [Constant.IMAGE.itemCode] }); } },
					{ text: 'Back', onPress: () => { } },
				]);
			}
		}
	};
	const setDown = () => {
		setIsVisible(false)
	}

	return useObserver(() => (
		<View style={[containerStyle.default]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<View style={styles.content}>
				<View style={styles.topView} />
				{_renderHeader()}
				<KeyboardAwareScrollView
					keyboardShouldPersistTaps='always'
					extraHeight={100}
					contentContainerStyle={{ flex: 1, width: '100%', height: '100%', backgroundColor: 'white' }}>
					<GiftedChat
						messages={messagesList}
						text={msg}
						onInputTextChanged={text => setMsg(text)}
						onSend={messages => onSend(messages)}
						user={{
							_id: userDetail?.userId,
							avatar: userDetail?.avatar,
							name: userDetail?.name
						}}
						listViewProps={{ initialNumToRender: 10 }}
						alwaysShowSend={true}
						primaryStyle={styles.primaryInputToolBarStyle}
						textInputStyle={styles.textInputStyle}
						textStyle={styles.textSendStyle}
						dateFormat={'ddd LT'}
						imageStyle={{ backgroundColor: 'white' }}
						imageProps={{ backgroundColor: 'white' }}
						renderSend={renderSend}
						renderAvatarInput={Platform.OS === 'ios' ? renderAvatarInput : null}
					// minComposerHeight={30}
					/>
					{Platform.OS === 'android' ? renderAvatarInput() : null}
				</KeyboardAwareScrollView>
				<ModalActionSheet
					onPressDrop={() => setDown()}
					isVisible={isVisible} onPress={(item, index) => {
						console.log(index);
						setIsVisible(false);
						if (index === 3) {
							return;
						}
						if (index === 0) {
							setIsLoading(true);
							setTimeout(() => {
								blockUser();
							}, 2000);
							return;
						}
						if (index === 1) {
							setIsLoading(true);
							setTimeout(() => {
								deleteUser();
							}, 2000);
							return;
						}
					}} />
				<ModalPingMessage style={{ height: ScreenWidth * 0.8 }} isVisible={block}
					title={'You have blocked this user'}
					subTitle={'This user will not be available with you\n.Now you can chat with each other!'}
					onPress={() => {
						setBlock(false);
						NavigationService.goBack();
					}} />
				<ModalPingMessage style={{ height: ScreenWidth * 0.8 }} isVisible={deleteFr}
					title={'You have deleted this friend'}
					subTitle={'You will get more better friends.\nNow you can chat with each other!'}
					onPress={() => {
						setDeleteFr(false);
						NavigationService.goBack();
					}} />
			</View>
			{isLoading ? <Loading /> : null}
		</View>
	));
};

export default withTheme(ChatRoomScreen);