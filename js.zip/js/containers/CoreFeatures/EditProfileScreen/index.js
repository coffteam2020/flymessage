import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {Keyboard, SafeAreaView, StatusBar, View} from 'react-native';
import {Appearance, useColorScheme} from 'react-native-appearance';
import ImagePicker from 'react-native-image-picker';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {withTheme} from 'react-native-paper';
import {NavigationService} from '../../../navigation';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import CheckDone from '../../../shared/components/CheckDone';
import Calendar from '../../../shared/components/Icons/Calendar';
import LocationIcon from '../../../shared/components/Icons/LocationIcon';
import Loading from '../../../shared/components/Loading';
import TextInputFlat from '../../../shared/components/TextInput/TextInputFlat';
import TextInputFlatLeftIconTouchable from '../../../shared/components/TextInput/TextInputFlatLeftIconTouchable';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import {colors} from '../../../shared/utils/colors/colors';
import Constant from '../../../shared/utils/constant/Constant';
import {uploadFileToFireBase} from '../../../shared/utils/firebaseStorageUtils';
import {ENUM_TIME_FORMAT} from '../../../shared/utils/helper/timeHelper';
import icons from '../../../shared/utils/icons/icons';
import LogManager from '../../../shared/utils/logging/LogManager';
import {useStores} from '../../../store/useStore';
import {containerStyle} from '../../../themes/styles';
import {styles} from './style';
import Back from '../../../shared/components/Icons/Back';
import AxiosFetcher from '../../../api/AxiosFetch';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
var moment = require('moment');

const EditProfileScreen = (props) => {
	const {colorsApp} = props.theme;
	const colorScheme = useColorScheme();
	console.log(colorScheme);
	const isDark = colorScheme === 'dark';
	const [, setAvatar] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const [isSuccess, setIsSuccess] = useState(false);
	const {t} = useTranslation();
	const [, setUnixBirthday] = useState(moment().unix());
	const {userStore} = useStores();
	const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
	const [userTempInfo, setUserTempInfo] = useState(userStore.userInfo);
	const [, setUri] = useState(Constant.MOCKING_DATA.PLACE_HOLDER);


	const IMAGE_CONFIG = {
		title: t('imagePicker.name'),
		cancelButtonTitle: t('common.cancel'),
		takePhotoButtonTitle: t('imagePicker.camera'),
		chooseFromLibraryButtonTitle: t('imagePicker.name'),
		storageOptions: {
			skipBackup: true,
			path: 'images',
		},
	};

	const showDatePicker = () => {
		Keyboard.dismiss();
		setDatePickerVisibility(true);
	};

	const hideDatePicker = () => {
		setDatePickerVisibility(false);
	};

	const handleConfirm = date => {
		setUnixBirthday(moment(date).valueOf());
		setUserTempInfo({...userTempInfo, dateOfBirth: moment(date).valueOf()});
		hideDatePicker();
	};
	const onBirthdayChange = () => {
	};
	const onChangeAddress = text => {
		setUserTempInfo({
			...userTempInfo, 
			addressStr: text,
		});
	};
	useEffect(() => {
		console.log(LogManager.parseJsonObjectToJsonString(userStore));
		setUserTempInfo(userStore.userInfo);
		getUserInfo();
	}, []);

	const getUserInfo = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		let token = await IALocalStorage.getTokenUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/person/' + userInfoId.id,
			hasToken: true,
			token: token
		})
			.then(async val => {
				setIsLoading(false);
				userStore.setUserInfo(val);
				await IALocalStorage.setDetailUserInfo(val);
				setUserTempInfo(val);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your information right now. Something wrong');
			});
	};

	const openImagePicker = () => {
		ImagePicker.showImagePicker(IMAGE_CONFIG, (response) => {
			// console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			} else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			} else {
				const source = {uri: response.uri};
				setUri(source.uri);
				setIsLoading(true);
				Promise.resolve(uploadFileToFireBase(response, userStore.userKey)).then(val => {
					setIsLoading(false);
					setAvatar(val);
					setUserTempInfo({...userTempInfo, avatar: val});
				}).catch(error => {
					console.log(error.message);
					ToastHelper.showError(t('error.common'));
					setIsLoading(false);
				});
			}
		});
	};

	const renderTopHeader = () => {
		return (
			<View style={[containerStyle.horContainerNearly, {justifyContent: 'space-between', alignItems: 'center'}]}>
				<Back props={props} onPress={() => NavigationService.goBack()} />
			</View>
		);
	};

	const renderField = () => {
		let userInfo = userTempInfo || {};
		return (
			<View style={[containerStyle.defaultMarginTop, {alignItems: 'center'}]}>
				<ImageAvtRectRounded resizeMode='cover' clickable onPress={() => openImagePicker()}
					icon={icons.IC_EDIT_PROFILE}
					style={[styles.avatar]} uri={userInfo.avatar || Constant.MOCKING_DATA.PLACE_HOLDER} />
				<TextInputFlat onChangeText={text => setUserTempInfo({...userTempInfo, email: text})} value={userTempInfo?.email} text={t('login.email')} props={props} style={styles.fieldItem} />
				<TextInputFlat onChangeText={text => setUserTempInfo({...userTempInfo, name: text})} value={userTempInfo?.name || userTempInfo?.firstName} text={t('introduce.firstName')} props={props} style={styles.fieldItem} />
				<TextInputFlatLeftIconTouchable
					value={moment(userInfo?.dateOfBirth || new Date().getTime()).format(ENUM_TIME_FORMAT.DATE_MONTH_YEAR)}
					onPress={() => {
						showDatePicker();
						return;
					}}
					onChangeText={(text) => onBirthdayChange(text)}
					text={t('introduce.birthDay')}
					props={props}
					style={containerStyle.defaultTextInput}
					hasLeftIcon ico={<Calendar props={props} />} />
				<TextInputFlatLeftIconTouchable
					onChangeText={(text) => onChangeAddress(text)}
					value={userInfo?.addressStr || ''}
					text={t('introduce.address')}
					props={props}
					style={containerStyle.defaultTextInput}
					hasLeftIcon ico={<LocationIcon color={colors.green} />} />
			</View>
		);
	};

	const updateProfile = async () => {
		setIsLoading(true);
		AxiosFetcher({
			method: 'POST',
			data: {
				...userTempInfo,
				name: userTempInfo.name,
			},
			url: '/api/person/update',
			hasToken: true,
		})
			.then(() => {
				setIsLoading(false);
				userStore.setUserInfo(userTempInfo);
				setIsSuccess(true);
				setTimeout(()=>{
					setIsSuccess(false);
					NavigationService.goBack();
				}, 2000);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Update your information failed. Please try again');
			});
	};

	return (
		<View style={[containerStyle.default, {backgroundColor: colors.pinkBackground}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView style={containerStyle.default}>
				<KeyboardAwareScrollView>
					<View style={[containerStyle.paddingDefault]}>
						{renderTopHeader()}
						{renderField()}
						<GradientButton text={t('common.done')} onPress={() => { updateProfile(); }} />
					</View>
				</KeyboardAwareScrollView>
				{isLoading ? <Loading /> : null}
				{isSuccess ? <CheckDone /> : null}
				<DateTimePickerModal
					isVisible={isDatePickerVisible}
					mode="date"
					isDarkModeEnabled={isDark}
					onConfirm={handleConfirm}
					onCancel={hideDatePicker}
					date={new Date(userTempInfo?.dateOfBirth || new Date().getTime())}
					cancelTextIOS={t('common.cancel')}
					confirmTextIOS={t('common.confirm')}
					headerTextIOS={t('common.pickADate')}
				/>
			</SafeAreaView>
		</View>
	);
};

export default withTheme(EditProfileScreen);
