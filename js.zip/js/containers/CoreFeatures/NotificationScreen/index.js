import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, FlatList, TouchableOpacity} from 'react-native';
import {styles} from './style';
import {withTheme} from 'react-native-paper';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Back from '../../../shared/components/Icons/Back';
import Loading from '../../../shared/components/Loading';
import icons from '../../../shared/utils/icons/icons';
import NotificationView from '../../../shared/components/Icons/NotificationView';
import Setting from '../../../shared/components/Icons/Setting';
import TextNormal from '../../../shared/components/Text/TextNormal';
import Constant from '../../../shared/utils/constant/Constant';
import {colors} from '../../../shared/utils/colors/colors';
import *  as Animatable from 'react-native-animatable';
import {TimeHelper} from '../../../shared/utils/helper/timeHelper';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import {useStores} from '../../../store/useStore';
import {FirebaseService} from '../../../api/FirebaseService';
import AxiosFetcher from '../../../api/AxiosFetch';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import Empty from '../../../shared/components/Empty';

const NotificationScreen = (props) => {
	const {colorsApp} = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const {t} = useTranslation();
	const {userStore} = useStores();
	const [notification, setNotis] = useState([]);

	useEffect(() => {
		getNotifications();
	}, []);
	const getNotifications = async () => {
		let userInfo = await IALocalStorage.getDetailUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/useraction/' + userInfo?.userId +  '/notifications',
			hasToken: true,
		})
			.then(val => {
				setIsLoading(false);
				userStore.setUserNotification(val);
				setNotis(val);
			})
			.catch(err => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your notification list, please try again');
			});
	};
	const getIconByType = type => {
		switch (type) {
		case Constant.NOTIFICATION_TYPES.APPOINTMENT:
			return icons.NOTIFICATION_STATUS_APPOINTMENT;
		case Constant.NOTIFICATION_TYPES.CARD:
			return icons.NOTIFICATION_STATUS_CARD;
		case Constant.NOTIFICATION_TYPES.MISSCALL:
			return icons.NOTIFICATION_STATUS_MISSED_CALL;
		case Constant.NOTIFICATION_TYPES.PROFILE:
			return icons.NOTIFICATION_STATUS_PROFILE;
		case Constant.NOTIFICATION_TYPES.MESSAGE:
			return icons.NOTIFICATION_STATUS_MESSAGE;
		case Constant.NOTIFICATION_TYPES.GOTCALL:
			return icons.NOTIFICATION_STATUS_GOT_CALL;
		default:
			return icons.NOTIFICATION_STATUS_MESSAGE;
		}
	};

	const renderItemNotification = (item, index) => {
		return (
			<Animatable.View animation="fadeIn" delay={index * 200}>
				<TouchableOpacity onPress={() => { }} style={[containerStyle.horContainerWithOutCenter, styles.itemNoti]}>
					<View style={[containerStyle.horContainerWithCenter, {width: 50, justifyContent: 'center', alignItems: 'center'}]}>
						{getIconByType(item.type)}
					</View>
					<View style={styles.contentNoti}>
						<TextNormal numberOfLines={4} props={props} text={item?.message || ''} style={[containerStyle.textNormal, styles.contentNoti]} />
						<TextNormal numberOfLines={4} props={props} text={TimeHelper.getTimeDefaultFormatFull(item?.createdOn)} style={[containerStyle.textDefaultContent, styles.contentNoti]} />
					</View>
				</TouchableOpacity>
			</Animatable.View>
		);
	};
	const renderNotification = () => {
		return (
			<FlatList
				showsVerticalScrollIndicator={false}
				data={userStore.userNotifications.slice().sort(function (a, b) { return a.createdAt - b.createdAt; })}
				renderItem={({item, index}) => renderItemNotification(item, index)}
				key={(item) => item.id}
				keyExtractor={(item) => item.id}
			/>
		);
	};
	const renderTitle = () => {
		return (
			<TextNormal text={t('notification.name')} style={[containerStyle.textHeader, containerStyle.defaultTextMarginLeft]} props={props} />
		);
	};
	
	return (
		<View style={[containerStyle.default]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView style={[containerStyle.default, containerStyle.paddingDefault]}>
				<View style={containerStyle.paddingDefault}>
					<View style={[containerStyle.horContainerNearlyDefault, containerStyle.centerFlexBegin, containerStyle.defaultMarginBottom]}>
						<Back props={props} />
						{renderTitle()}
					</View>

					{notification.slice().length === 0 ? <Empty /> : renderNotification()}	
				</View>
				
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(NotificationScreen);
