import {useObserver} from 'mobx-react';
import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {SafeAreaView, StatusBar, Image, View, ImageBackground, TouchableOpacity} from 'react-native';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {ScreenWidth, ScreenHeight} from '../../../shared/utils/dimension/Divices';
import {containerStyle} from '../../../themes/styles';
import {styles} from './style';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import {images} from '../../../../assets';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import ModalPingMessage from '../../../shared/components/Modal/ModalPinMessage';
import AxiosFetcher from '../../../api/AxiosFetch';
import {useNavigationParam} from 'react-navigation-hooks';
import {TimeHelper} from '../../../shared/utils/helper/timeHelper';
import Loading from '../../../shared/components/Loading';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {NavigationService} from '../../../navigation';
import CheckDone from '../../../shared/components/CheckDone';
import Constant from '../../../shared/utils/constant/Constant';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Sound from 'react-native-sound';
import {ScreenNames} from '../../../route/ScreenNames';
import { useStores } from '../../../store/useStore';

const PinMessageScreen = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const {userStore, homeStore} = useStores();
	const [isShowModal] = useState(false);
	const [isLoading, setIsLoading] = useState(false);
	const [isSuccess, setSuccess] = useState(false);
	const [modalRelease, setModalRelease] = useState(false);
	const [modalKeep, setModalKeep] = useState(false);
	const [isPlaying, setIsPlaying] = useState(false);
	const [recordPlayer, setRecordPlayer] = useState('');

	let data = useNavigationParam('data');
	let isDirectly = useNavigationParam('isDirectly');
	useEffect(() => {
		initPlayer();
		updateReadFloatingMsg();
	}, [data]);

	const updateReadFloatingMsg = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			url: 'api/useraction/' + userInfoId?.id + '/read/message/' + data?.id,
			hasToken: true,
		}).then(val => {
		}).catch(() => {
		});
	};
	const renderTopHeader = () => {
		return (
			<HeaderWithBackBtn props={props} title="" />
		);
	};

	const initPlayer = async () => {
		if (data?.itemType === 'VOICE') {
			Sound.setCategory('Playback');
			let audioPlayer = new Sound(data?.mediaUrl, '', (error) => {
				if (error) {
					return;
				}
				console.log('load success');
			});
			setRecordPlayer(audioPlayer);
		}
	};

	const playPauseRecord = async () => {
		if (isPlaying) {
			recordPlayer.pause();

		} else {
			recordPlayer.play((success) => {
				if (success) {
					console.log('successfully finished playing');
					setIsPlaying(false);
				} else {
					console.log('playback failed due to audio decoding errors');
				}
			});
		}
		setIsPlaying(!isPlaying);
	};

	const renderMessage = () => {
		return (
			<ImageBackground resizeMethod="resize" resizeMode='stretch' source={images.white_paper}
				style={[{height: ScreenHeight * 0.6, marginTop: 20, borderRadius: 18, width: ScreenWidth * 0.8}]}>
				<View style={{marginTop: -50, justifyContent: 'center', alignItems: 'center'}}>
					<ImageAvtRectRounded resizeMode='cover' style={{borderRadius: 50, width: 100, height: 100,}}
						uri={data?.fromUserAvatar || Constant.MOCKING_DATA.PLACE_HOLDER} />
					<TextNormal style={[containerStyle.defaultMarginTop, containerStyle.textHeaderSmall]}
						text={data?.fromUserName || ''} />
					<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textContent]}
						text={data?.createdOn ? `${TimeHelper.convertTimeFromDefaultFormat(data?.createdOn)}` : ''} />
					<View style={{paddingStart: 15, paddingEnd: 20}}>
						<TextNormal numberOfLines={100}
							style={[containerStyle.defaultMarginTopSmall, containerStyle.textDefaultNormal, containerStyle.paddingDefault]}
							text={data?.message || ''} />
					</View>
					{data?.mediaUrl ?
						(data?.messageType === 'VOICE' ?
							<View style={styles.viewItemVoice}>
								<TouchableOpacity onPress={() => { playPauseRecord(); }} style={styles.iconPlayPause}>
									{isPlaying && <Ionicons name="ios-pause" size={48} color={'red'} />}
									{!isPlaying && <Ionicons name="ios-play" size={48} color={'red'} />}
									<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textContent]}
										text="voice message" />
								</TouchableOpacity>
							</View> :
							<View style={styles.viewItem}>
								<ImageAvtRectRounded clickable onPress={()=>{
									homeStore.setShowImageZoom(true, data?.mediaUrl);
								}} style={styles.item} uri={data?.mediaUrl} />
							</View>
						) :
						null}
				</View>

			</ImageBackground>
		);
	};
	const release = async () => {
		setIsLoading(true);
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			url: '/api/useraction/' + userInfoId?.id + '/releaseFloatingMessage/' + data?.id,
			hasToken: true,
		}).then(val => {
			setIsLoading(false);
			setSuccess(true);
			setModalRelease(true);
		}).catch(() => {
			setSuccess(false);
			setModalRelease(false);
			setIsLoading(false);
			ToastHelper.showError('Oops. Tried to release this floating message but failed. Please try again');
		});
	};
	const keep = async () => {
		setIsLoading(true);
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'POST',
			url: '/api/useraction/' + userInfoId?.id + '/keepFloatingMeesage',
			data: data,
			hasToken: true,
		}).then(val => {
			setIsLoading(false);
			setSuccess(true);
			setModalKeep(true);

		}).catch(() => {
			setSuccess(false);
			setModalRelease(false);
			setIsLoading(false);
			ToastHelper.showError('Oops. Tried to keep this floating message but failed. Please try again');
		});
	};
	const renderBtns = () => {
		return (
			<View>
				{data?.messageType === 'TEXT' && <TouchableOpacity onPress={() => NavigationService.navigate(ScreenNames.TranslateScreen, {text: data?.message || ''})} style={{zIndex: 10, position: 'absolute', bottom: 60, width: '17%', left: '34%', justifyContent: 'center', alignItems: 'center', backgroundColor: Constant.COLOR_BACKGROUND_BTN[0], height: ScreenWidth * 0.17, borderRadius: ScreenWidth * 0.085, borderColor: 'white', borderWidth: 1.5}}>
					<MaterialCommunityIcons name="translate" size={40} color={'white'} />
				</TouchableOpacity>}
				<View style={[containerStyle.horContainerWithCenterDefault, {marginTop: 40, width: '100%', zIndex: 1}]}>
					<GradientButton onPress={() => {
						release();
					}} textStyle={containerStyle.text} fromColor="#FFA99E" toColor="#FFA99E" text="RELEASE"
					style={{width: ScreenWidth * 0.4, marginEnd: 5, borderRadius: 13, backgrounColor: '#FFA99E'}} />
					<GradientButton onPress={() => {
						keep();
					}} textStyle={containerStyle.text} text="KEEP" style={{width: ScreenWidth * 0.4, marginLeft: 5, borderRadius: 13}} />
				</View>
			</View>
		);
	};
	return useObserver(() => (
		<View style={[containerStyle.default, containerStyle.defaultBackgroundSecond]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<ImageBackground source={images.bg} style={{width: '100%', height: '100%'}}>
				<SafeAreaView style={[{alignItems: 'center'}]}>
					{renderTopHeader()}
					{renderMessage()}
					{renderBtns()}
				</SafeAreaView>
				<ModalPingMessage isVisible={isShowModal} />
			</ImageBackground>
			{isLoading ? <Loading /> : null}
			{isSuccess ? <CheckDone /> : null}
			<ModalPingMessage isVisible={modalRelease} title={'Release Message'}
				subTitle={`Thank you for checking out ${data?.fromUserName} message`} onPress={() => {
					setModalRelease(false);
					NavigationService.goBack();
				}} />
			<ModalPingMessage isVisible={modalKeep} title={'New friend added'}
				subTitle={`You have a new friend ${data?.fromUserName}\nNow you can chat with each other!`}
				onPress={() => {
					setModalKeep(false);
					NavigationService.goBack();
				}} />
		</View>
	));
};

export default withTheme(PinMessageScreen);
