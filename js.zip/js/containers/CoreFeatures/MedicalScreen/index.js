import {useObserver} from 'mobx-react';
import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {SafeAreaView, ScrollView, StatusBar, TouchableOpacity, View} from 'react-native';
import {withTheme} from 'react-native-paper';
import {NavigationService} from '../../../navigation';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import RectViewRounded from '../../../shared/components/Rect/RectViewRounded';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {colors} from '../../../shared/utils/colors/colors';
import Constant from '../../../shared/utils/constant/Constant';
import {ScreenWidth} from '../../../shared/utils/dimension/Divices';
import icons from '../../../shared/utils/icons/icons';
import {useStores} from '../../../store/useStore';
import TrackPlayer from 'react-native-track-player';
import {FONTSIZES, SPACINGS} from '../../../themes';
import {containerStyle} from '../../../themes/styles';
import {styles} from './style';
import {ScreenNames} from '../../../route/ScreenNames';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import AxiosFetcher from '../../../api/AxiosFetch';

const MedicalScreen = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const {userStore, homeStore} = useStores();
	const [isLoading, setIsLoading] = useState(false);
	useEffect(() => {
		getUserInfo();
	}, []);
	const getUserInfo = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		let token = await IALocalStorage.getTokenUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/person/' + userInfoId.id,
			hasToken: true,
			token: token
		})
			.then(val => {
				setIsLoading(false);
				userStore.setUserInfo(val);
			})
			.catch(err => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your information, please try again');
			});
	};
	const renderTopHeader = () => {
		return (
			<View style={styles.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{position: 'absolute', left: 0, padding: SPACINGS.small}}>
					{icons.IC_CLOSE}
				</TouchableOpacity>
				<TextNormal props={props} text={t('appName')} style={[containerStyle.textHeader, {}]} />
			</View>
		);
	};

	const renderHeader = () => {
		let userInfo = userStore?.userInfo || {};
		let firstName = userInfo?.name || 'User Name';
		let rank = userInfo?.ranking || 0;
		let location = userInfo?.addressStr || '_Not yet updated_';
		return (
			<View style={[{flexDirection: 'row'}]}>
				<View onPress={() => { }} style={{flexDirection: 'row',}}>
					<ImageAvtRectRounded resizeMode='cover' clickable style={[containerStyle.avatarRectRoundedDefault, {alignSelf: 'flex-start'}]} uri={userInfo.avatar || Constant.MOCKING_DATA.PLACE_HOLDER} />
					<View style={{marginLeft: SPACINGS.default, width: ScreenWidth * 0.8 - SPACINGS.xLarge * 2 - containerStyle.avatarRectRoundedDefault.width, height: containerStyle.avatarRectRoundedDefault.height, justifyContent: 'center'}}>
						<TextNormal text={`${firstName}`} props={props} style={[styles.textDefaultHeader]} />
						<TextNormal text={`Your id: ${userInfo.userId}`} props={props}/>
						<View style={{flexDirection: 'row', marginTop: SPACINGS.sSmall}}>
							{icons.IC_START}
							<TextNormal
								text={`${t('medical.rank')}: `}
								props={props}
								style={[styles.textDefaultContent, {fontSize: FONTSIZES.xSmall, color: colors.textPuple, marginLeft: SPACINGS.sSmall}]} />
							<TextNormal
								text={rank}
								style={[styles.btnTextStyle, {fontSize: FONTSIZES.xSmall, color: colors.textPuple, marginLeft: SPACINGS.sSmall}]} />
						</View>
						<View style={{flexDirection: 'row', marginTop: SPACINGS.sSmall}}>
							<View style={{marginLeft: 2}}>
								{icons.IC_LOCATION_MENU}
							</View>
							<TextNormal text={location} props={props} style={[styles.textDefaultContent, {fontSize: FONTSIZES.xSmall, marginLeft: SPACINGS.sSmall}]} />
						</View>
					</View>
				</View>
			</View>
		);
	};

	const renderSupport = () => {
		return (
			<View style={{marginTop: SPACINGS.xLarge}}>
				{renderItem(icons.IC_PROFILE_MENU, t('medical.myProfile'), () => NavigationService.navigate(ScreenNames.EditProfileScreen))}
				{renderItem(icons.IC_GIFT, t('medical.store'), () => NavigationService.navigate(ScreenNames.StoreScreen))}
				{renderItem(icons.IC_BASKET, t('medical.itemBag'), () => NavigationService.navigate(ScreenNames.ItemsScreen))}
				{renderItem(icons.IC_MEDICAL, 'Ranking', () => {NavigationService.navigate(ScreenNames.RankScreen); }, false, true)}
				{renderItem(icons.IC_NOTIFICATIONS_MENU, t('medical.notifications'), () => {NavigationService.navigate(ScreenNames.NotificationScreen);})}
				{renderItem(icons.IC_SETTINGS_MENU, t('medical.settings'), () => {NavigationService.navigate(ScreenNames.SettingsScreen);  })}
				{renderItem(icons.IC_ALERT, t('medical.about'), () => {NavigationService.navigate(ScreenNames.AboutScreen); }, false, true)}
				{renderItem(icons.IC_ALERT, 'Term and Condition', () => {NavigationService.navigate(ScreenNames.TermScreen); }, false, true)}
			</View>
		);
	};

	const renderItem = (ico, name, onPress, isEnd) => {
		return useObserver(() => (
			<TouchableOpacity onPress={onPress} style={[containerStyle.horContainerWithCenter, styles.item]}>
				<View style={containerStyle.horContainerWithCenter}>
					<View>
						{ico}
					</View>
					<TextNormal props={props} text={name} style={[containerStyle.defaultTextMarginLeft, styles.textDefaultContent]} />
				</View>
				<View style={{marginRight: SPACINGS.small}}>
					{icons.IC_CHEVRON_RIGHT}
				</View>
			</TouchableOpacity>
		));
	};
	const logout = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'POST',
			url: '/api/person/' + userInfoId?.id + '/fcmtoken',
			data: '__',
			hasToken: true,
		}).then(() => {
		}).catch(() => {
			ToastHelper.showError('Update token for notification got error');
		});
		await IALocalStorage.resetLocalStorage();
		await IALocalStorage.setUserInfo(null);
		await IALocalStorage.setDetailUserInfo(null);
		// await userStore.setUserInfo(null);
		NavigationService.navigate(ScreenNames.LoginScreen);
	};
	return useObserver(() => (
		<View style={[containerStyle.default]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<View style={styles.topView} />
				{renderTopHeader()}
				<ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom: 50}}>
					<View style={styles.content}>
						<RectViewRounded props={props} children={renderHeader()} style={styles.headerContent} />
						{renderSupport()}
						<GradientButton style={{marginTop: SPACINGS.xxLarge}} textStyle={styles.btnTextStyle} text={t('medical.logOut').toUpperCase()} onPress={async () => { logout();}} />
					</View>
				</ScrollView>
			</SafeAreaView>
		</View>
	));
};

export default withTheme(MedicalScreen);
