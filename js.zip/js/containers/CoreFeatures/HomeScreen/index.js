import { useObserver } from 'mobx-react';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Image, ScrollView, StatusBar, TouchableOpacity, View, RefreshControl } from 'react-native';
import { withTheme } from 'react-native-paper';
import { images } from '../../../../assets';
import { NavigationService } from '../../../navigation';
import { ScreenNames } from '../../../route/ScreenNames';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { useStores } from '../../../store/useStore';
import { containerStyle } from '../../../themes/styles';
import * as Animatable from 'react-native-animatable';
import TrackPlayer from 'react-native-track-player';
import { styles } from './style';
import { firebase } from '@react-native-firebase/messaging';
import AxiosFetcher from '../../../api/AxiosFetch';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import Loading from '../../../shared/components/Loading';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Constant from '../../../shared/utils/constant/Constant';
import Speaker from '../../../shared/components/Speaker';
import LogManager from '../../../shared/utils/logging/LogManager';
import { colors } from '../../../shared/utils/colors/colors';
var moment = require('moment-timezone');

const HomeScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	const [isLoading, setIsLoading] = useState(false);
	const [floatingMsg, setFloatingMsg] = useState([]);
	const { userStore } = useStores();
	const [isPlaying, setIsPlaying] = useState(false);
	const [textItemCount, setTextItemCount] = useState(0);
	// let spinValue = new Animated.Value(0);
	React.useEffect(() => {
		getFloatingMsg();
		getUserInfo();
		getFriendList();
		getBlockList();
		trackingPlayer();
		getRemainingMessage();
		props?.navigation.addListener('willFocus', () => {
			getFloatingMsg();
			getRemainingMessage();
			getUserInfo();
			getFriendList();
			getBlockList();
			// trackingPlayer();
		});

		props?.navigation.addListener('willUnmount', () => {
			TrackPlayer.pause();
		});

		// Return the function to unsubscribe from the event so it gets removed on unmount
		// return unsubscribe;
		checkPermission();
		return () => {
			TrackPlayer.stop();
		};
	}, [props?.navigation]);

	const checkPermission = async () => {
		const enabled = await firebase.messaging().hasPermission();
		if (enabled) {
			getToken();
		} else {
			requestPermission();
		}
	};

	const getToken = async () => {
		let fcmToken = await firebase.messaging().getToken();
		let userInfoId = await IALocalStorage.getUserInfo();
		console.log('FCM TOKEN ' + fcmToken);
		if (fcmToken) {
			AxiosFetcher({
				method: 'POST',
				url: '/api/person/' + userInfoId?.id + '/fcmtoken',
				data: fcmToken,
				hasToken: true,
			}).then(() => {
			}).catch(() => {
				ToastHelper.showError('Update token for notification got error');
			});
		}
	};

	const requestPermission = async () => {
		try {
			await firebase.messaging().requestPermission();
			// User has authorised
			this.getToken();
		} catch (error) {
			// User has rejected permissions
			console.log('permission rejected');
			alert('Notification permission rejected. Please open it in your Setting');
		}
	};
	const trackingPlayer = async () => {
		const music = await IALocalStorage.getMusic();
		if (music && music === '1') {
			// Set up the player
			await TrackPlayer.setupPlayer();
			await TrackPlayer.add({
				id: 'trackId1',
				url: 'https://firebasestorage.googleapis.com/v0/b/stayalone-6e26f.appspot.com/o/2019-04-20_-_Quiet_Time_-_David_Fesliyan.mp3?alt=media&token=158741f8-6c29-4c12-940e-e551a25cbbc7',
				title: 'Quited time for StayAlone',
				artist: 'Quiet time for you',
			});
			await TrackPlayer.add({
				id: 'trackId2',
				url: 'https://firebasestorage.googleapis.com/v0/b/stayalone-6e26f.appspot.com/o/2020-04-28_-_We_Were_Friends_-_David_Fesliyan.mp3?alt=media&token=272dbc8d-fdcc-4fe2-b2e4-6c85a2f03fe9',
				title: 'Quited time for StayAlone',
				artist: 'Quiet time for you',
			});
			await TrackPlayer.add({
				id: 'trackId3',
				url: 'https://firebasestorage.googleapis.com/v0/b/stayalone-6e26f.appspot.com/o/2019-04-06_-_Deep_Meditation_-_David_Fesliyan.mp3?alt=media&token=1b9d946e-b123-4d4a-9ff0-f9d01eaf44d9',
				title: 'Quited time for StayAlone',
				artist: 'Quiet time for you',
			});
			// Start playing it
			if (userStore?.userInfo?.id != '') {
				// setIsPlaying(true);
				await TrackPlayer.play();
			} else {
				await TrackPlayer.stop();
			}
		} else {
			await TrackPlayer.stop();
			ToastHelper.showWarning('You seem disable background music. Go to setting to enable and enjoy yourself')
		}
	};

	async function getFloatingMsg() {
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			url: '/api/useraction/' + userInfoId?.id + '/allFloatingMessage',
			data: undefined,
			hasToken: true,
		}).then(val => {
			if (val) {
				console.log("====" + JSON.stringify(val));
				let res = val || [];
				if (typeof res === 'object' && res?.length) {
					setFloatingMsg(res);
					let countTextItem = 0;
					for (let i = 0; i < res?.length; i++) {
						if (res[i]?.messageType === 'TEXT') {
							countTextItem++;
						}
					};
					setTextItemCount(countTextItem);
				} else {
					setFloatingMsg([]);
				}
			} else {
				setFloatingMsg([]);
			}
		}).catch((err) => {
			ToastHelper.showError(err || err?.message || 'Can not get floating messages for now. Please try again');
		});
	}

	const getUserInfo = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		let token = await IALocalStorage.getTokenUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/person/' + userInfoId?.id,
			hasToken: true,
			token: token
		})
			.then(async val => {
				setIsLoading(false);
				await IALocalStorage.setDetailUserInfo(val);
				userStore.setUserInfo(val);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your information right now, something wrong');
			});

		//Timezone
		AxiosFetcher({
			method: 'PUT',
			data: undefined,
			url: '/api/useraction/' + userInfoId?.id + '/timezone?timezone=' + moment.tz.guess(),
			hasToken: true,
			token: token
		})
			.then(async val => {
			})
			.catch(() => {
			});
	};

	const getRemainingMessage = async () => {
		let userInfoId = await IALocalStorage.getUserInfo();
		// http://api.stayalone.net/api/person/{userId}/remainingMessage
		//Timezone
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: '/api/person/' + userInfoId?.id + '/remainingMessage',
			hasToken: true,
		})
			.then(async val => {
				userStore.setFlyMessageRemain(val);
			})
			.catch(() => {
			});
	};

	async function getBlockList() {
		let userInfo = await IALocalStorage.getUserInfo();
		const token = await IALocalStorage.getTokenUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: `/api/useraction/${userInfo?.id}/allBlockedFriends/`,
			hasToken: true,
			token: token
		})
			.then(async val => {
				userStore.setBlockList(val);
				setIsLoading(false);
			})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your blocked user. Please try again');
			});
	}
	async function getFriendList() {
		let userInfo = await IALocalStorage.getUserInfo();
		let token = await IALocalStorage.getTokenUserInfo();
		const userId = userInfo?.id;
		setIsLoading(true);
		AxiosFetcher({
			method: 'GET',
			url: `/api/useraction/${userId}/friends`,
			hasToken: true,
			token: token
		}).then(async val => {
			const friends = val.filter(res => res.userId != userId);
			userStore.setFriendList(friends);
			setIsLoading(false);

		})
			.catch(() => {
				setIsLoading(false);
				ToastHelper.showError('Could not get your friends, please try again');
			});
	}


	const _renderHeader = () => {
		return (
			<View style={styles.header}>
				<TouchableOpacity onPress={() => NavigationService.navigate(ScreenNames.MedicalScreen)} style={{ padding: 5, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', width: 30, height: 30 }}>
					<Image
						source={images.ic_menu}
						style={styles.menuIcon}
					/>
				</TouchableOpacity>
				<TextNormal props={props} text={t('appName')} style={[containerStyle.textHeader, {}]} />
				<TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.MessageScreen); }} style={{ flexDirection: 'row' }}>
					<Animatable.Image
						animation={'pulse'}
						iterationCount={'infinite'}
						source={images.ic_messaging}
						style={styles.messageIcon}
					/>
				</TouchableOpacity>
			</View>
		);
	};
	const randomAndSorting = () => {
		let items = userStore?.itemsBag?.slice() || [];
		let quantity = 0;
		for (let i = 0; i < items?.length; i++) {
			if (items[i]?.itemCode === '1594059927928') {
				quantity = items[i]?.quantity;
				break;
			}
		}

		return useObserver(() => (
			<View style={{ flexDirection: 'row' }}>
				<Image source={images.window} resizeMode="contain" />
				<TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.PigeonMessageScreen); }} style={styles.birdIcon}>
					<Animatable.Image source={images.bird} resizeMode="contain" animation="pulse" iterationCount={100} />
					<View style={[styles.birdIcon, { right: -9, top: 38, zIndex: -1 }]}>
						<AntDesign name="tags" size={45} color={colors.red} />
					</View>
					<TextNormal props={props} text={`${(!floatingMsg?.length || floatingMsg?.length === 0) ? 0 : (floatingMsg?.length - textItemCount >= 0 ? floatingMsg?.length - textItemCount : 0)}`} style={[containerStyle.textDefaultContent, { zIndex: 10, color: colors.whiteBackground, alignSelf: 'center' }, { right: -20, bottom: 2, zIndex: -1 }]} />
				</TouchableOpacity>
				<TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.PinNewMessageScreen, { isHome: true }); }} style={styles.pencilIcon}>
					<Animatable.Image source={images.pencil_box} resizeMode="contain" animation={'tada'} iterationCount='infinite' iterationDelay={5000} />
					<View style={{ width: 16, height: 16, borderRadius: 8, backgroundColor: 'red', position: 'absolute', bottom: -5, right: 0, justifyContent: 'center', alignContent: 'center', alignItems: 'center' }}>
						<TextNormal props={props} text={userStore?.userFlyMessageRemaining >= 0 ? userStore?.userFlyMessageRemaining : '0'} style={[containerStyle.textContentSmall, { color: 'white', alignSelf: 'center' }]} />
					</View>
				</TouchableOpacity>
				{floatingMsg && typeof floatingMsg === 'object' && floatingMsg?.filter(item => item?.messageType === 'TEXT').map((item, index) => {
					if (index === 0) {
						return (
							<>
								<TouchableOpacity key={index} onPress={() => { NavigationService.navigate(ScreenNames.PinMessageScreen, { data: item }); }} style={[styles.paper1, containerStyle.shadow, { right: 5 * index }]}>
									<Animatable.View animation='rubberBand' iterationCount='infinite' iterationDelay={1500}>
										<Animatable.Image source={{ uri: item?.fromUserAvatar || Constant.MOCKING_DATA.PLACE_HOLDER }} resizeMode='cover' resizeMethod="resize" animation="slideInDown" style={{ width: 40, height: 40, borderRadius: 20, marginLeft: 10 }} />
										<Animatable.Image source={images.paper_plan_1} resizeMode="contain" animation="slideInDown" />
									</Animatable.View>
								</TouchableOpacity>
							</>
						);
					}
					if (index % 2 === 0) {
						return (
							<>
								<TouchableOpacity key={index} onPress={() => { NavigationService.navigate(ScreenNames.PinMessageScreen, { data: item }); }} style={[styles.paper3, { right: 10 * index }]}>
									<Animatable.View animation='tada' iterationCount='infinite' iterationDelay={2000}>
										<Animatable.Image source={{ uri: item?.fromUserAvatar || Constant.MOCKING_DATA.PLACE_HOLDER }} resizeMode='cover' resizeMethod="resize" style={{ width: 40, height: 40, borderRadius: 20, marginLeft: 20 }} />
										<Animatable.Image source={images.paper_plan_2} resizeMode="contain" animation="slideInRight" />
									</Animatable.View>
								</TouchableOpacity>
							</>
						);
					}
					return (
						<TouchableOpacity key={item?.id} onPress={() => { NavigationService.navigate(ScreenNames.PinMessageScreen, { data: item }); }} style={[styles.paper2, { right: 2 * index }]}>
							<Animatable.View animation='swing' iterationCount='infinite' iterationDelay={2000}>
								<Animatable.Image source={{ uri: item?.fromUserAvatar || Constant.MOCKING_DATA.PLACE_HOLDER }} resizeMode='cover' resizeMethod="resize" style={{ width: 40, height: 40, borderRadius: 20, marginLeft: 20 }} />
								<Animatable.Image source={images.paper_plan_3} resizeMode="contain" animation="slideInLeft" />
							</Animatable.View>
						</TouchableOpacity>
					);
				})}
			</View>
		));
	};

	return useObserver(() => (
		<View style={[styles.mainContainer]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			{_renderHeader()}
			<ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false} refreshControl={
				<RefreshControl refreshing={false} onRefresh={() => {
					getFloatingMsg();
					getRemainingMessage();
					getUserInfo();
					getFriendList();
					getBlockList();
				}} />
			}>
				<View style={styles.topView}>
					{randomAndSorting()}
				</View>
				<View style={styles.bottomView}>
					<View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
						<TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.Livestream); }} style={styles.tvIcon}>
							<Animatable.Image source={images.tv} resizeMode="contain" />
						</TouchableOpacity>
						{/* <TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.PlayList); }} style={styles.radioIcon}>
							<Speaker />
							<Animatable.Image source={images.radio} resizeMode="contain" duration={100} iterationDelay={4000} iterationCount='infinite' />
						</TouchableOpacity> */}
						<Image source={images.rectangle} resizeMode="contain" style={styles.rectangle} />
					</View>
					<Image source={images.closet} resizeMode="cover" style={styles.closetIcon} />
					<Image source={images.floor} resizeMode="stretch" style={styles.floorIcon} />
					<Image source={images.multi_lines} resizeMode="stretch" style={styles.multiLinesIcon} />
					<View style={styles.ladyIcon}>
						<Animatable.Image source={images.lady} resizeMode="contain" />
					</View>
					<Image source={images.tree} resizeMode="contain" style={styles.treeIcon} />
					<Animatable.Image source={images.dog} resizeMode="contain" style={styles.dogIcon} iterationDelay={1500} />
				</View>
			</ScrollView>
			{isLoading ? <Loading /> : null}
		</View>
	));
};

export default withTheme(HomeScreen);
