import React, { useEffect, useState } from 'react';
import { StatusBar, View, SafeAreaView, TouchableOpacity, Switch } from 'react-native';
import { styles as style } from './style';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { containerStyle } from '../../../themes/styles';
import { useTranslation } from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import { NavigationService } from '../../../navigation';
import TrackPlayer from 'react-native-track-player';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { colors } from '../../../shared/utils/colors/colors';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import icons from '../../../shared/utils/icons/icons';
import { ScreenWidth, ScreenHeight } from '../../../shared/utils/dimension/Divices';
// import { Switch } from 'react-native-gesture-handler';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import { ScreenNames } from '../../../route/ScreenNames';
import AxiosFetcher from "../../../api/AxiosFetch";
import { useStores } from "../../../store/useStore";
import CheckDone from "../../../shared/components/CheckDone";
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';

const SettingsScreen = (props) => {
    const { colorsApp } = props.theme;
    const { t } = useTranslation();
    const { userStore } = useStores();
    const [isLoading, setIsLoading] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [userInfo, setUserInfo] = useState(userStore.userInfo);
    const [music, setMusic] = useState(false);
    const [currentSong, setCurrentSong] = useState(undefined);

    useEffect(() => {
        const checkMusic = () => {
            TrackPlayer.getCurrentTrack().then(val => {
                console.log(val);
                if (val) {
                    setMusic(true);
                    TrackPlayer.getTrack(val).then(val => {
                        setCurrentSong(val);
                    })
                } else {
                    setMusic(false);
                }
            }).catch(err => {
                setMusic(false);
            })
        }
        checkMusic();
    }, []);

    const updateProfile = async () => {
        const userId = userInfo && userInfo.userId;
        setIsLoading(true);
        setUserInfo({
            ...userInfo,
            notification: !userInfo.notification,
        });
        AxiosFetcher({
            method: 'GET',
            data: undefined,
            url: `/api/useraction/${userId}/notification/${userInfo && !userInfo.notification}`,
            hasToken: true,
        })
            .then(val => {
                setIsLoading(false);
                setIsSuccess(true);
                setTimeout(() => {
                    setIsSuccess(false);
                }, 2000);
            })
            .catch(err => {
                setIsLoading(false);
                ToastHelper.showError('Oops. We tried to updated notification setting but failed. Please try again');
            });
    };

    const renderItem = (ico, text, hasSwitch, onPress, onSwitch) => {
        return (
            <TouchableOpacity disabled={hasSwitch} onPress={onPress}>
                <View style={[containerStyle.horContainer, {
                    height: 70,
                    justifyContent: 'center',
                    alignContent: 'center',
                    paddingEnd: 20,
                    paddingLeft: 20
                }]}>
                    <View style={[containerStyle.horContainer]}>
                        <View style={style.icon}>
                            {ico}
                        </View>
                        <TextNormal text={text} style={containerStyle.textNormalBlackLarge} />
                    </View>
                    <View style={{ flex: 1, alignItems: 'flex-end' }}>
                        {hasSwitch && hasSwitch ?
                            <Switch
                                onValueChange={() => onSwitch ? onSwitch() : updateProfile()} value={userInfo?.notification}
                                trackColor={{
                                    true: containerStyle.defaultBackground.backgroundColor,
                                    false: colors.white
                                }} /> : null}
                    </View>
                </View>
                <View style={containerStyle.line} />
            </TouchableOpacity>
        );
    };
    const renderMusic = (ico, text, hasSwitch, onPress, onSwitch) => {
        return (
            <TouchableOpacity disabled={hasSwitch} onPress={onPress}>
                <View style={[containerStyle.horContainer, {
                    height: 70,
                    justifyContent: 'center',
                    alignContent: 'center',
                    paddingEnd: 20,
                    paddingLeft: 20
                }]}>
                    <View style={[containerStyle.horContainer]}>
                        <View style={style.icon}>
                            {ico}
                        </View>
                        <TextNormal text={text} style={containerStyle.textNormalBlackLarge} />
                    </View>
                    <View style={{ flex: 1, alignItems: 'flex-end' }}>
                        {hasSwitch && hasSwitch ?
                            <Switch
                                value={music}
                                onValueChange={async (a) => {
                                    if (a) {
                                        TrackPlayer.getCurrentTrack().then(val => {
                                            if (!val || val === '') {
                                                TrackPlayer.play();
                                            } else {
                                                TrackPlayer.play();
                                            }
                                            setMusic(true);
                                        })
                                    } else {
                                        setMusic(false);
                                        TrackPlayer.pause();
                                    }
                                    await IALocalStorage.setMusic(a ? '1' : '0');
                                }}
                                // onValueChange={() => onSwitch ? onSwitch() : {}} value={userInfo?.notification}
                                trackColor={{
                                    true: containerStyle.defaultBackground.backgroundColor,
                                    false: colors.white
                                }} /> : null}
                    </View>
                </View>
                <View style={containerStyle.line} />
            </TouchableOpacity>
        );
    };

    return (
        <View style={[containerStyle.center, { backgroundColor: colors.pinkBackground }]}>
            <StatusBar barStyle={colorsApp.statusBar} />
            <SafeAreaView>
                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                    <View>
                        <HeaderWithBackBtn props={props} title="Settings" />
                        <View style={[style.container, containerStyle.defaultMarginTop, {
                            backgroundColor: 'white',
                            width: ScreenWidth,
                            height: ScreenHeight,
                            paddingTop: 20
                        }]}>
                            {renderItem(icons.IC_NOTI, 'On/Off notification', true)}
                            {renderItem(icons.IC_KEY, 'Change password', false, () => NavigationService.navigate(ScreenNames.ResetScreen))}
                            {renderItem(icons.IC_BLOCK, 'Block list', false, () => NavigationService.navigate(ScreenNames.BlockFriendScreen))}
                            {renderMusic(icons.IC_GIFT, 'On/Off background music', true, () => {
                            }, () => {
                                TrackPlayer.getCurrentTrack().then(val => {
                                    TrackPlayer.getTrack(val).then(val => {
                                        console.log("======" + JSON.stringify(val));
                                    })
                                })
                            })}
                        </View>
                    </View>
                </KeyboardAwareScrollView>
                {isLoading ? <Loading /> : null}
                {isSuccess ? <CheckDone /> : null}
            </SafeAreaView>
        </View>
    );
};

export default withTheme(SettingsScreen);
