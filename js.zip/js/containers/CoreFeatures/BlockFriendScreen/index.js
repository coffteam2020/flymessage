import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, TouchableOpacity} from 'react-native';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {colors} from '../../../shared/utils/colors/colors';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import {ScreenWidth, ScreenHeight} from '../../../shared/utils/dimension/Divices';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import AxiosFetcher from '../../../api/AxiosFetch';
import {useStores} from '../../../store/useStore';
import {styles} from './style';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import Constant from '../../../shared/utils/constant/Constant';
import {useObserver} from 'mobx-react';
import Empty from '../../../shared/components/Empty';
import icons from '../../../shared/utils/icons/icons';

const BlockFriendScreen = (props) => {
    const {colorsApp} = props.theme;
    const {t} = useTranslation();
    const {userStore} = useStores();
    const [isLoading, setIsLoading] = useState(false);
    const [userInfo, setUserInfo] = useState(userStore.userInfo);
    const blockList = userStore?.blockList || [];
    useEffect(() => {
        getBlockList();
    }, []);

    const getBlockList = async () => {
        const userId = userInfo && userInfo.userId;
        const token = await IALocalStorage.getTokenUserInfo();
        setIsLoading(true);
        AxiosFetcher({
            method: 'GET',
            data: undefined,
            url: `/api/useraction/${userId}/allBlockedFriends/`,
            hasToken: true,
            token: token
        })
            .then(async val => {
                userStore.setBlockList(val);
                setIsLoading(false);
            })
            .catch(err => {
                setIsLoading(false);
                ToastHelper.showError('Block user failed. Please try again');
            });
        // setIsLoading(false);
    };
    const unBlockFriend = async (friendId) => {
        const userId = userInfo && userInfo.userId;
        const token = await IALocalStorage.getTokenUserInfo();
        setIsLoading(true);
        AxiosFetcher({
            method: 'GET',
            data: undefined,
            url: `/api/useraction/${userId}/unblock/${friendId}`,
            hasToken: true,
            token: token
        })
            .then(async val => {
                const newBlockList = userStore.blockList.filter((item) => item.userId !== friendId);
                userStore.setBlockList(newBlockList);
                setIsLoading(false);
            })
            .catch(err => {
                setIsLoading(false);
                ToastHelper.showError(t('error.common'));
            });
    };

    return useObserver(() => (
        <View style={[containerStyle.center, {backgroundColor: colors.pinkBackground}]}>
            <StatusBar barStyle={colorsApp.statusBar}/>
            <SafeAreaView>
                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                    <View>
                        <HeaderWithBackBtn props={props} title="Block List"/>
                        <View style={[containerStyle.defaultMarginTop, {
                            backgroundColor: 'white',
                            width: ScreenWidth,
                            height: ScreenHeight,
                        }]}>
                            {blockList?.slice().length === 0 ? <Empty/> : blockList.slice().map(
                                (item, index) => {
                                    return (
                                        <View
                                            key={index}
                                            style={[styles.item]}>
                                            <View
                                                style={[containerStyle.horContainer, {
                                                    paddingTop: 10,
                                                    paddingBottom: 10,
                                                    alignSelf: 'flex-start',
                                                    justifyContent: 'center',
                                                    alignItems: 'center'
                                                }]}>
                                                <ImageAvtRectRounded
                                                    style={[containerStyle.avatarRectRoundedDefault, {
                                                        width: ScreenWidth * 0.11,
                                                        height: ScreenWidth * 0.11,
                                                    }]}
                                                    uri={item.avatar || Constant.MOCKING_DATA.PLACE_HOLDER}/>
                                                <TextNormal props={props} text={item.name}
                                                            style={[styles.textDefaultHeader]}/>

                                            </View>
                                            <TouchableOpacity onPress={() => unBlockFriend(item.userId)}>
                                                <View style={styles.icon}>
                                                    {icons.IC_UNBLOCK}
                                                </View>
                                            </TouchableOpacity>
                                        </View>
                                    );
                                })}
                        </View>
                    </View>
                </KeyboardAwareScrollView>
                {isLoading ? <Loading/> : null}
            </SafeAreaView>
        </View>
    ));
};

export default withTheme(BlockFriendScreen);
