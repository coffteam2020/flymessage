import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView} from 'react-native';
import {styles as style} from './style';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {NavigationService} from '../../../navigation';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {ImageBackground} from 'react-native';
import {images} from '../../../../assets';
import Back from '../../../shared/components/Icons/Back';
import {colors} from '../../../shared/utils/colors/colors';

const ABOUT = `Meet, connect, chat and learn with friends all over the world, understand cultures and languages ​​through fly messages, audio channels and video streams.
In modern society, the application to connect with friends has become familiar and as part of your daily life. We created this application with nostalgic and dreamy ideas.
A letter folded in the form of an airplane and dropped into the vast sky carrying your message. It will randomly come to a friend you never knew and that's where a friendship begins.
We offer fly message feature - send random message.
We offer pigeon mailing - send messages with destination.
We bring radio - listen to the stories of friends.
We offer video stream - livestream and room interaction.
And other interesting features waiting for you to discover ...`;
const AboutScreen = (props) => {
	const {colorsApp} = props.theme;
	const [isLoading] = useState(false);
	useEffect(() => {

	}, []);

	return (
		<View style={[containerStyle.center, {backgroundColor: colors.pinkBackground}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<Back props={props} onPress={() => NavigationService.goBack()} style={{marginLeft: 20, marginTop: 20}} />
                <TextNormal numberOfLines={2} props={props} text={'StayAlone App'} style={[containerStyle.textHeader, {marginLeft: 20}]} />
				<KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
					<View>
						<View style={[style.container, {backgroundColor: 'white'}]}>

							<View style={style.fieldContainer}>
								<TextNormal numberOfLines={2} props={props} text={'Version 1.0.0'} />
								<View style={containerStyle.line} />
								<TextNormal numberOfLines={100} props={props} text={ABOUT} style={[containerStyle.textNormalBlackLarge]} />
							</View>
						</View>
					</View>
				</KeyboardAwareScrollView>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(AboutScreen);
