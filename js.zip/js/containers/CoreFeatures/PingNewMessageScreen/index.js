import { useObserver } from 'mobx-react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SafeAreaView, StatusBar, Text, View, ImageBackground, TextInput, Image, TouchableOpacity, Alert } from 'react-native';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { ScreenWidth, ScreenHeight } from '../../../shared/utils/dimension/Divices';
import { containerStyle } from '../../../themes/styles';
import { styles } from './style';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import { images } from '../../../../assets';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import ModalPingMessage from '../../../shared/components/Modal/ModalPinMessage';
import ModalItem from '../../../shared/components/Modal/ModalItem';
import { utils } from '@react-native-firebase/app';
import vision from '@react-native-firebase/ml-vision';
import AxiosFetcher from '../../../api/AxiosFetch';
import { useNavigationParam } from 'react-navigation-hooks';
import { TimeHelper } from '../../../shared/utils/helper/timeHelper';
import Loading from '../../../shared/components/Loading';
import { NavigationService } from '../../../navigation';
import RNFSHelper from './rnfshelper';
import CheckDone from '../../../shared/components/CheckDone';
import { useStores } from '../../../store/useStore';
import Constant from '../../../shared/utils/constant/Constant';
import LogManager from '../../../shared/utils/logging/LogManager';
import AntDesign from 'react-native-vector-icons/AntDesign';

import { colors } from '../../../shared/utils/colors/colors';
import icons from '../../../shared/utils/icons/icons';
import ImagePicker from 'react-native-image-picker';
import { uploadFileToFireBase } from '../../../shared/utils/firebaseStorageUtils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Sound from 'react-native-sound';
import { ScreenNames } from '../../../route/ScreenNames';

const PinNewMessageScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	const [isShowModal] = useState(false);
	const [isLoading, setIsLoading] = useState(false);
	const [isSuccess, setSuccess] = useState(false);
	const [modalRelease, setModalRelease] = useState(false);
	const { userStore } = useStores();

	let isDirectly = useNavigationParam('isDirectly');
	let isHome = useNavigationParam('isHome') || false;
	let data = useNavigationParam('data');
	const [floatingMsg, setFloatingMsg] = useState('');

	const [modalItem, setModalItem] = useState(false);
	const [modelSelect, setModalSelect] = useState('');
	const [itemActive, setItemActive] = useState(null);
	const [isPlaying, setIsPlaying] = useState(false);
	const [recordPlayer, setRecordPlayer] = useState('');

	useEffect(() => {
	}, []);

	const renderTopHeader = () => {
		return (
			<HeaderWithBackBtn props={props} title="" rightTitleChildren="Send" hasButton onPressRight={() => send()} />
		);
	};

	const openModel = async (type) => {
		setModalSelect(type);
		setModalItem(true);
	};

	const pauseOrResumeMusic = async () => {
		if (isPlaying) {
			recordPlayer.pause();

		} else {
			recordPlayer.play((success) => {
				if (success) {
					console.log('successfully finished playing');
					setIsPlaying(false);
				} else {
					console.log('playback failed due to audio decoding errors');
				}
			});
		}
		setIsPlaying(!isPlaying);
	};

	const renderItem = () => {
		if (modelSelect === 'VOICE') {
			return (
				<View style={styles.viewItem}>
					{itemActive &&
						<View style={styles.itemGroupAudio}>
							<TouchableOpacity style={styles.closeIcon} onPress={() => removeItem()}>
								<AntDesign name="closecircle" size={20} color={colors.red} />
							</TouchableOpacity>
							<TouchableOpacity onPress={() => { pauseOrResumeMusic(); }} style={styles.iconPlayPause}>
								{isPlaying && <Ionicons name="ios-pause" size={48} color={'red'} />}
								{!isPlaying && <Ionicons name="ios-play" size={48} color={'red'} />}
								<Text>Audio Message</Text>
							</TouchableOpacity>
						</View>}
				</View>
			);
		} else {
			return (
				<View style={styles.viewItem}>
					{itemActive &&
						<View style={styles.itemGroup}>
							<TouchableOpacity style={styles.closeIcon} onPress={() => removeItem()}>
								<AntDesign name="closecircle" size={20} color={colors.red} />
							</TouchableOpacity>
							<ImageAvtRectRounded clickable onPress={() => removeItem()} resizeMode='contain' style={styles.item}
								uri={itemActive?.itemUrl || Constant.MOCKING_DATA.PLACE_HOLDER} />
						</View>}
				</View>
			);
		}
	};

	const IMAGE_CONFIG = {
		title: t('imagePicker.name'),
		cancelButtonTitle: t('common.cancel'),
		takePhotoButtonTitle: t('imagePicker.camera'),
		chooseFromLibraryButtonTitle: t('imagePicker.name'),
		storageOptions: {
			skipBackup: true,
			path: 'images',
		},
	};

	const openImagePicker = async () => {
		ImagePicker.showImagePicker(IMAGE_CONFIG, async (response) => {
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			} else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			} else {
				// let rnfsHelper = new RNFSHelper();
				// const tempFile = await rnfsHelper.createTempFileIfIOS(response.uri);
				// const visionResp = (await RNTextDetector.detectFromUri(response.uri)) || [];
				// const visionText = visionResp.map(v => v.text).join();

				// this.setState({
				//   selectedImages: [],
				//   imageUrl: tempFile,
				//   visionText: visionText,
				//   showCamera: false,
				//   showCameraRollPicker: false,
				// });
				// console.log(LogManager.parseJsonObjectToJsonString(visionText))

				// const tessOptions = {
				// 	whitelist: null, 
				// 	blacklist: '1234567890\'!"#$%&/()={}[]+*-_:;<>'
				//   };
				//   RNTesseractOcr.recognize(response.uri, 'vn', tessOptions)
				// 	.then((result) => {
				// 	  this.setState({ ocrResult: result });
				// 	  console.log("OCR Result: ", result);
				// 	})
				// 	.catch((err) => {
				// 	  console.log("OCR Error: ", err);
				// 	})
				// 	.done();

				Alert.alert(
					'Which type of message do you want to choose?',
					'',
					[
						{
							text: 'Text detected',
							onPress: async () => {
								try {
									setIsLoading(true);
									const visionResp = await processDocument(response?.uri);
									// const visionResp = (await RNTextDetector.detectFromUri(response?.uri)) || [];
									setIsLoading(false);
									// const visionText = (visionResp || []).map(v => v.text).join();
									console.log('visionResp', visionResp);
									setFloatingMsg(visionResp);
								} catch (e) {
									setIsLoading(false);
									console.warn(e);
								}
							},
							style: 'cancel'
						},
						{
							text: 'Image', onPress: () => {
								setIsLoading(true);
								Promise.resolve(uploadFileToFireBase(response, userStore.userKey)).then(val => {
									setIsLoading(false);
									setItemActive({ itemUrl: val });
									setModalSelect('IMAGE');
								}).catch(error => {
									console.log(error.message);
									ToastHelper.showError(t('error.common'));
									setIsLoading(false);
								});
							}
						}
					],
					{ cancelable: false }
				);


			}
		});
	};
	async function processDocument(localPath) {
		const processed = await vision().cloudDocumentTextRecognizerProcessImage(localPath);

		console.log('Found text in document: ', processed.text);

		// processed.blocks.forEach(block => {
		//   console.log('Found block with text: ', block.text);
		//   console.log('Confidence in block: ', block.confidence);
		//   console.log('Languages found in block: ', block.recognizedLanguages);
		// });
		return processed.text;
	}
	const renderOptionSend = () => {
		return (
			<View style={styles.optionItem}>
				<TouchableOpacity
					style={styles.itemBtn}
					onPress={() => openImagePicker()}
				>
					{icons.IC_IMAGE_ITEM}
				</TouchableOpacity>

				<TouchableOpacity
					style={styles.itemBtn}
					onPress={() => {
						openModel('VOICE');
					}}
				>
					{icons.IC_MIC_ITEM}
				</TouchableOpacity>

				{!isHome && <TouchableOpacity
					style={styles.itemBtn}
					onPress={() => openModel('GIFT')}
				>
					{icons.IC_GIFT_ITEM}
				</TouchableOpacity>}

				{!isHome && <TouchableOpacity
					style={styles.itemBtn}
					onPress={() => openModel('GIFT')}
				>
					{icons.IC_FLY_ITEM}
				</TouchableOpacity>}
			</View>
		);
	};

	const renderMessage = () => {
		if (isDirectly && isDirectly && data && data?.userId) {
			return (
				<ImageBackground resizeMethod="resize" resizeMode="contain" source={images.white_paper} style={[styles.imgBackground]}>
					<View style={{ marginTop: -50, justifyContent: 'center', alignItems: 'center' }}>
						<ImageAvtRectRounded resizeMode='cover' style={{ borderRadius: 50, width: 100, height: 100, marginTop: 10 }} uri={data?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER} />
						<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textHeaderSmall]} text={data?.name || ''} />
						<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textContent]} text={`${TimeHelper.convertTimeFromDefaultFormat(new Date().getTime())}`} />
						<View style={styles.textMess}>
							<TextInput value={floatingMsg || ''} returnKeyType="done" maxLength={itemActive?.itemUrl && itemActive?.itemUrl != '' ? 100 : 10000} onChangeText={text => setFloatingMsg(text)} multiline numberOfLines={itemActive ? 20 : 100} style={[containerStyle.defaultMarginTopSmall, containerStyle.textDefaultNormal, containerStyle.paddingDefault, { textAlignVertical: 'top', height: ScreenHeight / 2 - 30, width: ScreenWidth - 80, marginLeft: 30 }]} />
						</View>
					</View>
				</ImageBackground>
			);
		}
		return (
			<ImageBackground resizeMethod="resize" resizeMode='stretch' source={images.white_paper} style={[styles.imgBackground]}>
				<View style={{ marginTop: -50, justifyContent: 'center', alignItems: 'center' }}>
					<ImageAvtRectRounded resizeMode='cover' style={{ borderRadius: 50, width: 100, height: 100, marginTop: 15 }} uri={userStore?.userInfo?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER} />
					<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textHeaderSmall]} text={userStore?.userInfo?.name || ''} />
					<TextNormal style={[containerStyle.defaultMarginTopSmall, containerStyle.textContent]} text={`${TimeHelper.convertTimeFromDefaultFormat(new Date().getTime())}`} />
					<View style={styles.textMess}>
						<TextInput value={floatingMsg || ''} onChangeText={text => setFloatingMsg(text)} multiline maxLength={itemActive?.itemUrl && itemActive?.itemUrl != '' ? 100 : 10000} numberOfLines={100} style={[containerStyle.defaultMarginTopSmall, containerStyle.textDefaultNormal, containerStyle.paddingDefault, styles.mess]} />
					</View>
				</View>
			</ImageBackground>
		);
	};

	const send = async () => {
		if (isHome && userStore?.userFlyMessageRemaining === 0) {
			// ToastHelper.showError('Could not send success. You reached maximum floating message today');
			Alert.alert('Opps', 'Maximum fly message has been sent today. Buy more gifts to send fly messages for connecting more friends?', [
				{ text: 'Buy now', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen); } },
				{ text: 'Back', onPress: () => { } }
			]);
			return;
		}
		if (floatingMsg.replace(' ', '') === '' && !itemActive) {
			ToastHelper.showError('Dont send empty message, your landed user will be sad');
			return;
		}
		setIsLoading(true);
		let userInfoId = await IALocalStorage.getUserInfo();
		let body = {
			'createdOn': new Date().getTime(),
			'fromUserAvatar': userStore?.userInfo?.avatar,
			'fromUserId': userInfoId?.id,
			'fromUserName': userStore?.userInfo?.name || '',
			'itemType': modelSelect || 'TEXT',
			'itemCode': itemActive && itemActive.itemCode,
			'message': floatingMsg,
			'mediaUrl': itemActive && itemActive.itemUrl,
			'messageType': modelSelect || 'TEXT',
			'isPigeon': !isHome
		};
		if (isDirectly && isDirectly && data && data?.userId) {
			body.receiverUserId = data?.userId;
		}
		console.log({ body });
		AxiosFetcher({
			method: 'POST',
			url: '/api/useraction/' + userInfoId?.id + '/sendFloatingMessage',
			data: body,
			hasToken: true,
		}).then(val => {
			setIsLoading(false);
			if (val) {
				setSuccess(true);
				setModalRelease(true);
				AxiosFetcher({
					method: 'POST',
					url: `/api/${userInfoId?.id}/useItem/AIRPLANE`,
					hasToken: true,
				});
			} else {
				setSuccess(false);
				setModalRelease(false);
				ToastHelper.showError(isHome ?  'You only send 3 messages floating once day' : 'Send your item failed. Please check your bag');
				// ToastHelper.showError('Could not send success. You reached maximum floating message today. Buy more item to send');
				// Alert.alert('Opps', 'Maximum fly message has been sent today. Buy more gifts to send fly messages for connecting more friends?', [
				// 	{ text: 'Buy now', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen); } },
				// 	{ text: 'Back', onPress: () => { } }
				// ]);
			}
		}).catch((err) => {
			setSuccess(false);
			setModalRelease(false);
			setIsLoading(false);
			ToastHelper.showError(isHome ?  'You only send 3 messages floating once day' : 'Send your item failed. Please check your bag');
			// Alert.alert('Opps', 'Maximum fly message has been sent today. Buy more gifts to send fly messages for connecting more friends?', [
			// 	{ text: 'Buy now', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen) } },
			// 	{ text: 'Back', onPress: () => { } }
			// ]);
		});
	};

	const updateActiveItem = (item) => {
		setModalItem(false);
		setItemActive(item);
	};
	const removeItem = () => {
		setItemActive(null);
		// setModalSelect('TEXT');
		// setModalItem(false);
	};
	const recordAudio = async (item, itemLocal) => {
		setItemActive({ attachmentImageUrl: item });
		setModalSelect('VOICE');
		setModalItem(false);
		Sound.setCategory('Playback');
		let audioPlayer = new Sound(itemLocal, '', (error) => {
			if (error) {
				return;
			}
		});
		setRecordPlayer(audioPlayer);
	};

	return useObserver(() => (
		<View style={[containerStyle.default, containerStyle.defaultBackgroundSecond]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<ImageBackground source={images.bg} style={{ width: '100%', height: '100%', zIndex: 0 }}>
				<SafeAreaView style={[{ alignItems: 'center', zIndex: 0, }]}>
					<KeyboardAwareScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ flexWrap: 'wrap', alignItems: 'center', zIndex: 0, }}>
						{renderTopHeader()}
						{renderMessage()}
						{renderItem()}
						{renderOptionSend()}
					</KeyboardAwareScrollView>
				</SafeAreaView>
				<ModalPingMessage isVisible={isShowModal} />
			</ImageBackground>
			{isLoading ? <Loading /> : null}
			{isSuccess ? <CheckDone /> : null}
			<ModalPingMessage isVisible={modalRelease} title={'Bon Voyage'}
				subTitle={'Your fly message is en route'} onPress={() => {
					setModalRelease(false);
					NavigationService.goBack();
				}} />
			{
				modelSelect ?
					<ModalItem
						isVisible={modalItem}
						title={modelSelect}
						onUse={(item) => updateActiveItem(item)}
						onRecord={(item, itemLocal) => recordAudio(item, itemLocal)}
						onPress={() => {
							setModalItem(false);
						}}
						onClose={() => setModalItem(false)}
					/> : null
			}
		</View>
	));
};

export default withTheme(PinNewMessageScreen);
