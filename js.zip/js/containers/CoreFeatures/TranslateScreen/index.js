import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, TouchableOpacity} from 'react-native';
import {styles as style} from './style';
import Modal from 'react-native-modal';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {NavigationService} from '../../../navigation';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Back from '../../../shared/components/Icons/Back';
import {colors} from '../../../shared/utils/colors/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {ScreenWidth, ScreenHeight} from '../../../shared/utils/dimension/Divices';
import Constant from '../../../shared/utils/constant/Constant';
import {useNavigationParam} from 'react-navigation-hooks';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import {ScrollView} from 'react-native-gesture-handler';
const TranslateScreen = (props) => {
	const {colorsApp} = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const [textTranslated, setTextTranslated] = useState('');
	const [visible, setVisible] = useState(false);
	const [af, setAf] = useState('vi');
	const [afN, setAfN] = useState('Vietnamese');
	let text = useNavigationParam('text');
	useEffect(() => {
		
	}, []);

	const translateFunc = async (text, target) => {
		setIsLoading(true);
		await fetch('https://translation.googleapis.com/language/translate/v2?key=AIzaSyCtnwTU1m0i3ZxHWVgVpJtK1n24nM4zmTI&target=' + target +'&q=' + text, {method: 'GET'})
			.then(val => {
				return val.json();
			})
			.then(res => {
				setTimeout(() => {
					setIsLoading(false);
				}, 500);

				console.log(res?.data?.translations[0]?.translatedText);
				setTextTranslated(res?.data?.translations[0]?.translatedText || '');
			})
			.catch(() => {
				setIsLoading(false);
			});
	};

	const renderHeader = () => {
		return (
			<View style={style.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{flexDirection: 'row'}}>
					<Back props={props} onPress={() => NavigationService.goBack()} style={{marginLeft: 20}} />
				</TouchableOpacity>
				<TextNormal props={props} text={'Translation'} style={[containerStyle.textHeader, {color: colors.textBlue, textAlignVertical: 'center'}]} />
				<TouchableOpacity style={{flexDirection: 'row', width: ScreenWidth * 0.15}}>
				</TouchableOpacity>
			</View>
		);
	};

	const renderModal = () => {
		return (
			<Modal
				transparent
				animationType="slide"
				visible={visible}
				// supportedOrientations={SUPPORTED_ORIENTATIONS}
				style={{flex: 1}}
				onRequestClose={() => {
					setVisible(false);
				}}
			>
				<View style={{flex: 1, justifyContent: 'center'}}>
					<View style={{height: ScreenWidth * 1.1, backgroundColor: 'white', width: ScreenWidth * 0.9}}>
						<TouchableOpacity style={{position: 'absolute', zIndex: 10, top: 10, right:10}} onPress={()=>setVisible(false)}>
							<AntDesign name="closecircle" size={20}/>
						</TouchableOpacity>
						<ScrollView contentContainerStyle={{paddingBottom: 50, paddingTop: 20}} style={{borderRadius: 10, width: ScreenWidth * 0.9, height: ScreenWidth * 1.1, borderColor: 'rgba(0,0,0,0.2)', borderWidth: 1}}>
							{Constant.COUNTRIES.map(item => {
								return (
									<TouchableOpacity key={item?.name} style={{padding: 10}} onPress={()=>{
									}}>
										<TextNormal text={item?.name} clickable onPress={()=>{
											setVisible(false);
											setAf(item?.key);
											setAfN(item?.name);
											translateFunc(text, item?.key);
										}}/>
									</TouchableOpacity>
								);
							})}
						</ScrollView>
					</View>
				</View>
			</Modal>
		);
	};
	return (
		<View style={[{backgroundColor: colors.pinkBackground}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderHeader()}
				<KeyboardAwareScrollView contentContainerStyle={{backgroundColor: 'white', height: '100%'}} nestedScrollEnabled showsVerticalScrollIndicator={false} >
					<View style={{width: '80%', flexDirection: 'row', justifyContent: 'space-between', alignSelf: 'center', height: 50, alignItems: 'center'}}>
						<TextNormal text="Original" style={containerStyle.textDefault} />
						<AntDesign name="retweet" size={20} color={Constant.COLOR_BACKGROUND_BTN[0]} />
						<TextNormal text={afN} style={containerStyle.textDefault} clickable onPress={() => { setVisible(true); }} />
					</View>
					<View style={{width: '100%', height: 0.5, backgroundColor: 'rgba(0, 0, 0, 0.1)'}} />
					<View style={{backgroundColor: 'rgba(0,0,0,0.1)', padding: 10, paddingBottom: 20, marginTop: 20, width: '90%', alignSelf: 'center', borderRadius: 10}}>
						<TextNormal text={text} />
					</View>
					<View style={{marginTop: 20, width: '90%', alignSelf: 'center', borderRadius: 10}}>
						<TextNormal text={'Text translated'} style={containerStyle.textDefaultNormal} />
					</View>
					<View style={{backgroundColor: 'rgba(0,0,0,0.1)', padding: 10, paddingBottom: 20, marginTop: 20, width: '90%', alignSelf: 'center', borderRadius: 10}}>
						<TextNormal text={textTranslated} />
					</View>
					<GradientButton text="Translate" style={{width: '95%', alignSelf: 'center', marginTop: ScreenHeight / 5}} onPress={() => translateFunc(text, af)} />
				</KeyboardAwareScrollView>
			</SafeAreaView>
			{renderModal()}
			{isLoading ? <Loading /> : null}
		</View>
	);
};

export default withTheme(TranslateScreen);
