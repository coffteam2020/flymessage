
import React, { useEffect, useState } from 'react';
import { StatusBar, View, SafeAreaView, TouchableOpacity, ImageBackground, Alert } from 'react-native';
import { styles as style } from './style';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { containerStyle } from '../../../themes/styles';
import { useTranslation } from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import { NavigationService } from '../../../navigation';
import Back from '../../../shared/components/Icons/Back';
import { colors } from '../../../shared/utils/colors/colors';
import TrackPlayer from 'react-native-track-player';
import { firebase } from '@react-native-firebase/database';
import Constant from '../../../shared/utils/constant/Constant';
import { ScrollView } from 'react-native-gesture-handler';
import { ScreenWidth } from '../../../shared/utils/dimension/Divices';
import FastImage from 'react-native-fast-image';
import AntDesign from 'react-native-vector-icons/AntDesign';
import BottomTab from '../SpotifyScreen/BottomTab';
import { ScreenNames } from '../../../route/ScreenNames';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import LogManager from '../../../shared/utils/logging/LogManager';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import { useStores } from '../../../store/useStore';
import AxiosFetcher from '../../../api/AxiosFetch';
import { TimeHelper } from '../../../shared/utils/helper/timeHelper';

const PlayList = (props) => {
	const { colorsApp } = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const [mine, setMine] = useState([]);
	const [my, setMy] = useState([]);
	const [artist, setArtist] = useState([]);
	const [random, setRandom] = useState([]);
	const [isZoom, setZoom] = useState(false);
	const { userStore } = useStores();

	useEffect(() => {
		TrackPlayer.stop();
		props?.navigation.addListener('willFocus', () => {
			followMine();
			followArtist();
			getInfoItem();
			followMy();
		});
	}, [mine]);
	const getInfoItem = async () => {
		const userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: `/api/person/${userInfoId?.id}/itemsuser`,
			hasToken: true,
		})
			.then(async val => {
				userStore.setItemsBag(val || []);
			})
			.catch(() => {
			});
	};
	useEffect(() => {
		setTimeout(() => {
			followArtist();
			followMine();
			followMy();
		}, 200);
	}, []);

	const followMine = async () => {
		setIsLoading(true);
		// IALocalStorage.getDetailUserInfo().then(val => {
		// 	let id = `${val?.userId}`;
		// 	firebase.database().ref(Constant.SCHEMA.PLAYLIST).child(id).on('value', snapshot => {
		// 		if (snapshot.val() != undefined) {
		// 			let data = snapshot.val() || {};
		// 			let playList = data?.playList || [];
		// 			setMine(playList);
		// 		} else {
		// 			setMine([]);
		// 		}
		// 		setIsLoading(false);
		// 	});
		// });
		let user = await IALocalStorage.getDetailUserInfo();
		firebase.database().ref(Constant.SCHEMA.PLAYLIST).once('value', snapshot => { 
			if (snapshot.val() != undefined) {
				let data = Object.values(snapshot.val()) || [];
                
                let a = [];
                for (let i = 0 ; i<data.length ; i++) {
                    if (data[i]?.user?.userId === user?.userId) {
                        a?.push(data[i]);
                    }
                }
				setMine(a || []);
			} else {
				setMine([]);
			}
			setIsLoading(false);
		});
	};
	const followMy = async () => {
		let user = await IALocalStorage.getDetailUserInfo();
		firebase.database().ref(Constant.SCHEMA.AUDIO).once('value', snapshot => {
			if (snapshot.val() != undefined) {
				let data = Object.values(snapshot.val()) || [];
				let b = [];
				for (let i = 0; i < data.length; i++) {
					if (data[i]?.userOwnerInfo?.id === user?.userId) {
						let playList = data[i]?.playList || [];
						for (let j = 0; j < playList?.length; j++) {
							b.push({
								id: 'trackId' + j,
								audioUrl: playList[j]?.audioUrl || '',
								uri: playList[j]?.audioUrl || '',
								title: playList[j]?.title || '',
								artist: playList[j]?.desc || '',
								desc: playList[j]?.desc || '',
								userOwnerInfo: data[i]?.userOwnerInfo || {},
							})
						}
					}
				}
				setMy(b || []);
			} else {
				setMy([]);
			}
			// setIsLoading(false);
		});
	}
	const followArtist = async () => {
		setIsLoading(true);
		firebase.database().ref(Constant.SCHEMA.AUDIO).once('value', snapshot => {
			if (snapshot.val() != undefined) {
				let data = snapshot.val() || [];
				setArtist(data);

				// Random track
				let arr = [];
				let dataT = Object.values(data) || [];
				for (let i = 0; i < dataT?.length; i++) {
					let playList = dataT[i]?.playList || [];
					for (let j = 0; j < playList?.length; j++) {
						arr.push({
							id: 'trackId' + j,
							audioUrl: playList[j]?.audioUrl || '',
							uri: playList[j]?.audioUrl || '',
							title: playList[j]?.title || '',
							artist: playList[j]?.desc || '',
							desc: playList[j]?.desc || '',
							userOwnerInfo: dataT[i]?.userOwnerInfo || {},
						});
					}
				}
				// console.log(LogManager.parseJsonObjectToJsonString(arr));
				setRandom(arr);
			} else {
				setArtist([]);
			}
			setIsLoading(false);
			followMy();
			followMine();
			
		});
	};
	const checkPublish = async () => {
		NavigationService.navigate(ScreenNames.PlayListConfig);
		// setIsLoading(true);
		// const userInfoId = await IALocalStorage.getUserInfo();
		// AxiosFetcher({
		// 	method: 'GET',
		// 	data: undefined,
		// 	url: `/api/person/${userInfoId?.id}/itemsuser`,
		// 	hasToken: true,
		// })
		// 	.then(async val => {
		// 		userStore.setItemsBag(val || []);
		// 		let itemBags = val || [];
		// 		if (itemBags?.length === 0) {
		// 			Alert.alert('Opps,', 'You have to buy item Microphone to able to create new audio', [
		// 				{text: 'Let me buy', onPress: () => {NavigationService.navigate(ScreenNames.StoreScreen);}},
		// 				{text: 'Back', onPress: () => {}},
		// 			]);
		// 		} else {
		// 			let shouldMake = false;
		// 			for (let i = 0; i< itemBags?.length; i++){
		// 				if (itemBags[i].itemCode === '1594058493422' && itemBags[i]?.itemCode === '1594060169595' && itemBags[i]?.quantity > 0) {
		// 					shouldMake = true;
		// 					break;
		// 				}
		// 			}
		// 			if (shouldMake) {
		// 				NavigationService.navigate(ScreenNames.Recording);
		// 			} else {
		// 				Alert.alert('Opps,', 'You have to buy item Microphone to able to create new audio', [
		// 					{text: 'Let me buy', onPress: () => {NavigationService.navigate(ScreenNames.StoreScreen);}},
		// 					{text: 'Back', onPress: () => {}},
		// 				]);
		// 			}
		// 		}
		// 		setIsLoading(false);
		// 	})
		// 	.catch(() => {
		// 		Alert.alert('Opps,', 'You have to buy item Microphone to able to create new audio', [
		// 			{text: 'Let me buy', onPress: () => {NavigationService.navigate(ScreenNames.StoreScreen);}},
		// 			{text: 'Back', onPress: () => {}},
		// 		]);
		// 		setIsLoading(false);
		// 	});
	};
	const renderHeader = () => {
		return (
			<View style={style.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{ flexDirection: 'row' }}>
					<Back props={props} onPress={() => NavigationService.goBack()} style={{ marginLeft: 15 }} />
				</TouchableOpacity>
				<TextNormal props={props} text={'Radio'} style={[containerStyle.textHeader, { color: colors.textBlue, textAlignVertical: 'center' }]} />
				<TouchableOpacity onPress={() => { checkPublish(); }} style={{ flexDirection: 'row', marginEnd: 10, padding: 5 }}>
					<TextNormal props={props} text={'Publish'} style={[containerStyle.textContent, { color: colors.textBlue, textAlignVertical: 'center' }]} />
				</TouchableOpacity>
			</View>
		);
	};

	const renderPopular = () => {
		// Only 3 items
		const data = [
			{
				id: 1,
				name: 'Play a random track',
				desc: 'Help meditation',
				bgUrl: 'https://firebasestorage.googleapis.com/v0/b/stayalone-prod.appspot.com/o/Rectangle.png?alt=media&token=1f3eb43c-a7d8-4a8f-a134-f160f7c3fbe2'
			}
		];
		let dataTrack = {
			name: 'Random track',
			artist: 'Multiple artist',
			release: 2016,
			// eslint-disable-next-line global-require
			cover: require('../../../../assets/imgs/Jan-Blomqvist.jpg'),
			tracks: random
		};
		return (
			<View>
				<ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'flex-start', paddingVertical: 20 }}>
					{data?.map(item => {
						return (
							<ImageBackground key={item?.id} resizeMode="stretch" resizeMethod="resize" source={{ uri: item?.bgUrl }} style={{ width: ScreenWidth * 0.89, height: ScreenWidth * 0.45, alignSelf: 'flex-start', marginEnd: 10 }}>
								<TouchableOpacity onPress={() => NavigationService.navigate(ScreenNames.SpotifyScreen, { songs: dataTrack })} style={{ width: ScreenWidth * 0.89, height: ScreenWidth * 0.45, padding: 20 }} >
									<TextNormal numberOfLines={2} text={item?.name} style={[containerStyle.textHeader, { color: 'white', marginTop: 10, width: ScreenWidth * 0.45 }]} />
									<TextNormal numberOfLines={2} text={item?.name} style={[containerStyle.textDefaultContent, { color: 'white', position: 'absolute', left: 0, top: ScreenWidth * 0.1, width: ScreenWidth * 0.45 }]} />
									<TouchableOpacity style={{ position: 'absolute', bottom: 10, right: 10 }} onPress={async () => {
										try {
											NavigationService.navigate(ScreenNames.SpotifyScreen, { songs: dataTrack });
										} catch (err) {
											ToastHelper.showError(err?.message || 'Opps, err while trying seting up everything');
										}
									}}>
										<AntDesign name="play" color={'white'} size={35} />
									</TouchableOpacity>
								</TouchableOpacity>
							</ImageBackground>
						);
					})}
				</ScrollView>
			</View>
		);
	};
	const renderMine = () => {
		// Only 3 items
		let arr = [];
		let data1 = Object.assign({}, mine);
		let data = mine;
		while (data?.length > 0) {
			arr.push(data?.splice(0, 2));
		}
		
		data1 = Object.values(data1);
		let dataMore = {
			name: 'Your playlist',
			artist: 'Your playlist',
			release: 2016,
			// eslint-disable-next-line global-require
			cover: require('../../../../assets/imgs/Jan-Blomqvist.jpg'),
			tracks: my
		};
		console.log("===" + JSON.stringify(arr));
		return (
			<View style={[containerStyle.defaultMarginTop]}>
				<View style={[containerStyle.horContainerWithOutCenter, { marginBottom: 0 }]}>
					<TextNormal text="My playlist" style={[{ marginBottom: 0 }, containerStyle.textDefault]} />
					{/* <TextNormal clickable onPress={()=>{NavigationService.navigate(ScreenNames.SpotifyScreen, {songs: dataMore});}} text="See more" style={[{marginBottom: 0}, containerStyle.smallMarginTop]} /> */}
				</View>
				{arr && arr?.length > 0 ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'flex-start', paddingVertical: 20 }}>
					{arr?.map(item => {
						let f = item[0];
						let s = item[1];
						return (
							<View style={{ width: ScreenWidth * 0.7, marginEnd: 10 }}>
								{f && <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }} onPress={() => NavigationService.navigate(ScreenNames.SpotifyScreen, { songs: dataMore })}>
									<FastImage resizeMode="cover" resizeMethod="resize" source={{ uri: f?.backgroundUrl || Constant.MOCKING_DATA.NO_IMG_PLACE_HOLDER }} style={{ borderWidth: 2, borderColor: 'white', borderRadius: 10, width: 70, height: 70 }} />
									<View style={{ width: ScreenWidth * 0.5, height: 70, paddingLeft: 20, justifyContent: 'center', alignContent: 'center' }}>
										<TextNormal numberOfLines={2} text={f?.name} style={[containerStyle.textNormalBold, { width: ScreenWidth * 0.45 }]} />
										<TextNormal numberOfLines={2} text={TimeHelper.convertTimeDDMMYY(f?.createdOn)} style={[containerStyle.textContent, { width: ScreenWidth * 0.45 }]} />
									</View>
								</TouchableOpacity>}
								{s && <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center', marginTop: 10 }}>
									<FastImage resizeMode="cover" resizeMethod="resize" source={{ uri: s?.backgroundUrl || Constant.MOCKING_DATA.NO_IMG_PLACE_HOLDER }} style={{ borderWidth: 2, borderColor: 'white', borderRadius: 10, width: 70, height: 70 }} />
									<View style={{ width: ScreenWidth * 0.5, height: 70, paddingLeft: 20, justifyContent: 'center', alignContent: 'center' }}>
										<TextNormal numberOfLines={2} text={s?.name} style={[containerStyle.textNormalBold, { width: ScreenWidth * 0.45 }]} />
										<TextNormal numberOfLines={2} text={TimeHelper.convertTimeDDMMYY(s?.createdOn)} style={[containerStyle.textContent, { width: ScreenWidth * 0.45 }]} />
									</View>
								</TouchableOpacity>}
							</View>
						);
					})}
				</ScrollView> :
					<View>
						<TextNormal numberOfLines={2} text="You have not published any playlist. Start to publish for now" />
						<GradientButton text="Let me in" style={[containerStyle.buttonThird, { alignSelf: 'flex-end' }]} onPress={() => checkPublish()} />
					</View>}
			</View>
		);
	};
	const renderArtists = () => {
		// Only 3 items
		let arr = [];
		let data = Object.values(artist) || [];
		while (data?.length > 0) {
			arr.push(data?.splice(0, 2));
		}
		return (
			<View style={[containerStyle.defaultMarginTop]}>
				<View style={[containerStyle.horContainerWithOutCenter, { marginBottom: 0 }]}>
					<TextNormal text="Artists" style={[{ marginBottom: 0 }, containerStyle.textDefault]} />
					{/* <TextNormal clickable text="See more" style={[{marginBottom: 0}, containerStyle.smallMarginTop]} /> */}
				</View>
				{arr && arr?.length > 0 ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'flex-start', paddingVertical: 20 }}>
					{arr?.map(item => {
						let f = item[0];
						let s = item[1];
						return (
							<View style={{ width: ScreenWidth * 0.7, marginEnd: 10 }}>
								{f && <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }} onPress={() => {
									let dataMore = {
										name: f?.userOwnerInfo?.name,
										artist: f?.userOwnerInfo?.name,
										release: 2016,
										// eslint-disable-next-line global-require
										cover: { uri: f?.userOwnerInfo?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER },
										tracks: f?.playList || []
									};
									NavigationService.navigate(ScreenNames.SpotifyScreen, { songs: dataMore });
								}}>
									<FastImage resizeMode="cover" resizeMethod="resize" source={{ uri: f?.userOwnerInfo?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER }} style={{ borderWidth: 2, borderColor: 'white', borderRadius: 35, width: 70, height: 70 }} />
									<View style={{ width: ScreenWidth * 0.5, height: 70, paddingLeft: 20, justifyContent: 'center', alignContent: 'center' }}>
										<TextNormal numberOfLines={2} text={f?.userOwnerInfo?.name} style={[containerStyle.textNormalBold, { width: ScreenWidth * 0.45 }]} />
										<TextNormal numberOfLines={2} text={`${f?.playList?.length || '0'} records`} style={[containerStyle.textContent, { width: ScreenWidth * 0.45 }]} />
									</View>
								</TouchableOpacity>}
								{s && <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'center', alignContent: 'center', marginTop: 10 }} onPress={() => {
									let dataMore = {
										name: s?.userOwnerInfo?.name,
										artist: s?.userOwnerInfo?.name,
										release: 2016,
										// eslint-disable-next-line global-require
										cover: { uri: s?.userOwnerInfo?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER },
										tracks: s?.playList || []
									};
									NavigationService.navigate(ScreenNames.SpotifyScreen, { songs: dataMore });
								}}>
									<FastImage resizeMode="cover" resizeMethod="resize" source={{ uri: s?.userOwnerInfo?.avatar || Constant.MOCKING_DATA.PLACE_HOLDER }} style={{ borderWidth: 2, borderColor: 'white', borderRadius: 35, width: 70, height: 70 }} />
									<View style={{ width: ScreenWidth * 0.5, height: 70, paddingLeft: 20, justifyContent: 'center', alignContent: 'center' }}>
										<TextNormal numberOfLines={2} text={s?.userOwnerInfo?.name} style={[containerStyle.textNormalBold, { width: ScreenWidth * 0.45 }]} />
										<TextNormal numberOfLines={2} text={`${s?.playList?.length || '0'} songs`} style={[containerStyle.textContent, { width: ScreenWidth * 0.45 }]} />
									</View>
								</TouchableOpacity>}
							</View>
						);
					})}
				</ScrollView> :
					<View>
						<TextNormal numberOfLines={2} text="There are no artist. Contribute for now, do you?" />
						<GradientButton text="Add new record" style={[containerStyle.buttonHalf, { marginTop: 10, alignSelf: 'flex-end', paddingLeft: 10 }]} onPress={() => NavigationService.navigate(ScreenNames.Recording)} />
					</View>
				}
			</View>
		);
	};

	return (
		<View style={[{ backgroundColor: colors.pinkBackground, flex: 1 }]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderHeader()}
				<KeyboardAwareScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={{ paddingTop: 10, paddingLeft: 20, paddingEnd: 20, paddingBottom: 250 }}>
					{renderPopular()}
					{renderMine()}
					{renderArtists()}
				</KeyboardAwareScrollView>

				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(PlayList);
