import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, TouchableOpacity, Platform, PermissionsAndroid} from 'react-native';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {colors} from '../../../shared/utils/colors/colors';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import {ScreenWidth, ScreenHeight} from '../../../shared/utils/dimension/Divices';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import ImagePicker from 'react-native-image-picker';
import Permissions from 'react-native-permissions';
import {useStores} from '../../../store/useStore';
import CheckDone from '../../../shared/components/CheckDone';
import AntDesign from 'react-native-vector-icons/AntDesign';
import AudioRecord from 'react-native-audio-record';
import FastImage from 'react-native-fast-image';
import NoImage from '../../../shared/components/NoImage';
import {uploadFileToFireBase} from '../../../shared/utils/firebaseStorageUtils';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import TextInputFlat from '../../../shared/components/TextInput/TextInputFlat';
import {TimeHelper} from '../../../shared/utils/helper/timeHelper';
import {Buffer} from 'buffer';
import {firebase} from '@react-native-firebase/database';
var RNFS = require('react-native-fs');
import FilePickerManager from 'react-native-file-picker';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import Sound from 'react-native-sound';
import ModalWave from '../../../shared/components/Modal/ModalWave';
import MusicSpeaker from '../../../shared/components/MusicSpeaker';
import {FirebaseService} from '../../../api/FirebaseService';
import Constant from '../../../shared/utils/constant/Constant';
import LogManager from '../../../shared/utils/logging/LogManager';
import Wave from '../../../shared/components/Wave';
import {NavigationService} from '../../../navigation';
import DocumentPicker from 'react-native-document-picker';
import { useNavigationParam } from 'react-navigation-hooks';

var uuid = require('uuid');

const options = {
	sampleRate: 16000,  // default 44100
	channels: 1,        // 1 or 2, default 1
	bitsPerSample: 16,  // 8 or 16, default 16
	audioSource: 6,     // android only (see below)
	wavFile: 'test.wav' // default 'audio.wav'
};
AudioRecord.init(options);

AudioRecord.on('data', data => {
	const chunk = Buffer.from(data, 'base64');
	console.log('chunk size', chunk.byteLength);
});
const IMAGE_CONFIG = {
	title: 'Pick image background for room',
	cancelButtonTitle: 'Cancel',
	takePhotoButtonTitle: 'Camera',
	chooseFromLibraryButtonTitle: 'Gallery',
	storageOptions: {
		skipBackup: true,
		path: 'images',
	},
};

const Recording = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const {userStore} = useStores();
	const [time, setTime] = useState(0);
	const [isLoading, setIsLoading] = useState(false);
	const [data, setData] = useState(false);
	const [audioFile, setAudioFile] = useState('');
	const [isSuccess, setSuccess] = useState(false);
	const [isPlaying, setIsPlaying] = useState(false);
	const [isVisible, setVisible] = useState(false);
	const [url, setUrl] = useState(null);
	const [recordPlayer, setRecordPlayer] = useState('');
	const [recording, setRecording] = useState(false);
	const [timeInterval, setTimeInterval] = useState(0);
	const [uri, setUri] = useState(null);
	const [playlist, setPlaylist] = useState([]);
	const [userInfo, setUserInfo] = useState(userStore.userInfo);
	const playListInfo = props.navigation.state.params.playListInfo;

	useEffect(() => {

		checkPermission();
		checkRecordLimit();
	}, [time]);

	const pickFiles = async () => {
		// Pick a single file
		try {
			if (Platform.OS === 'android') {
				FilePickerManager.showFilePicker(null, (response) => {
					console.log('Response = ', response);
				  
					if (response.didCancel) {
					  console.log('User cancelled file picker');
					}
					else if (response.error) {
					  console.log('FilePickerManager Error: ', response.error);
					}
					else {
						if (response?.path) {
							setIsLoading(true);
							Promise.resolve(uploadFileToFireBase({
								uri: response?.path,
								path: response?.path
							}, userStore.userKey, '.wav')).then(async (val) => {
								setIsLoading(false);
								recordAudio(val, audioFile);
								setAudioFile(response?.path);
							}).catch(error => {
								setIsLoading(false);
								ToastHelper.showError('Opps. Error while retrieving your local files. Please try again later');
							});
						}
					}
				  });
			} else {
				DocumentPicker.pickMultiple({
					type: [
						DocumentPicker.types.audio,
					],
				})
					.then((res) => {
						console.log(
							LogManager.parseJsonObjectToJsonString(res)
						);
						if (!res[0]) {
							ToastHelper.showError('Could not retrieve your files picked.');
							return;
						}
						let uri = res[0]?.uri;
						if (!uri) {
							ToastHelper.showError('Could not retrieve your files. Please check manually your device settings');
							return;
						} else {
							setIsLoading(true);
							Promise.resolve(uploadFileToFireBase({
								uri: uri,
								path: uri
							}, userStore.userKey, '.wav')).then(async (val) => {
								setIsLoading(false);
								recordAudio(val, audioFile);
								setAudioFile(res?.uri);
							}).catch(error => {
								setIsLoading(false);
								ToastHelper.showError('Opps. Error while retrieving your local files. Please try again later');
							});
						}
					});
			}

		} catch (err) {
			ToastHelper.showError('Could not get files. Please try again later');
		}
	};
	const requestPermission = async () => {
		const p = await Permissions.request(Platform.OS === 'android' ? Permissions.PERMISSIONS.ANDROID.RECORD_AUDIO : Permissions.PERMISSIONS.IOS.MICROPHONE);
		if (p === Permissions.RESULTS.GRANTED) {
			return true;
		}
		return false;
	};

	const checkRecordLimit = () => {
		if (time >= 1800) {
			stop();
		}
	};

	const stop = async () => {
		if (!recording) return;
		const audioFile = await AudioRecord.stop();
		console.log('audioFile', audioFile);
		setIsLoading(true);
		setAudioFile(audioFile);
		setRecording(false);
		setVisible(false);
		clearInterval(timeInterval);
		Promise.resolve(uploadFileToFireBase({
			uri: audioFile,
			path: audioFile
		}, userStore.userKey, '.wav')).then(async (val) => {
			setIsLoading(false);
			console.log('=================', val);
			setTime(0);
			recordAudio(val, audioFile);
		}).catch(error => {
			console.log(error.message);
			ToastHelper.showError(t('error.common'));
		});
	};
	const recordAudio = async (item, itemLocal) => {
		setUrl(item);
		Sound.setCategory('Playback');
		let audioPlayer = new Sound(itemLocal, '', (error) => {
			if (error) {
				return;
			}
		});
		setRecordPlayer(audioPlayer);
	};
	const checkPermission = async () => {
		let p = await Permissions.check(Platform.OS === 'android' ? Permissions.PERMISSIONS.ANDROID.RECORD_AUDIO : Permissions.PERMISSIONS.IOS.MICROPHONE);
		if (p === Permissions.RESULTS.GRANTED)
			return true;
		else if (p === Permissions.RESULTS.BLOCKED) {
			ToastHelper.showError(t('setting.permission.record'));
			return false;
		}
		return await requestPermission();
	};
	const start = async () => {
		setVisible(true);
		setTime(0);
		setTimeout(async () => {
			let permisstion = await checkPermission();
			if (!permisstion) {
				return;
			}
			// console.log('start record');
			let interval = setInterval(() => {
				setTime(time => time + 1);
			}, 1000);
			setTimeInterval(interval);
			setAudioFile('');
			setRecording(true);
			AudioRecord.start();
		}, 500);
	};

	const uploadDB = async () => {
		if (!data?.title || data?.title === '') {
			ToastHelper.showError('Could not create song');
			return;
		}
		const userInfo = await IALocalStorage.getDetailUserInfo();
		let tagSplited = (data?.tags || [])?.split(',');
		for (let i = 0; i < tagSplited?.length; i++) {
			if (typeof tagSplited[i] === 'string') {
				if (!tagSplited[i]?.trim().includes('#')) {
					tagSplited[i] = '#' + tagSplited[i]?.trim();
					tagSplited[i] = tagSplited[i]?.trim();
				}
			}
		}
		let obj = {
			id: uuid.v4(),
			title: data?.title,
			desc: data?.desc,
			tags: tagSplited || [],
			createdAt: new Date().getTime(),
			userOwnerInfo: {
				id: userInfo?.userId,
				name: userInfo?.name,
				avatar: userInfo?.avatar,
			},
			audioUrl: url,
			backgroundUrl: uri
		};
		firebase.database().ref(Constant.SCHEMA.AUDIO).child(`${userInfo?.userId}`).once('value', snapshot => {
			if (snapshot.val() != undefined) {
				let data = snapshot.val() || [];
				let playList = data?.playList || [];
				playList.push(obj);
				data = {
					...data, playList: playList, userOwnerInfo: {
						id: userInfo?.userId,
						name: userInfo?.name,
						avatar: userInfo?.avatar,
					},
					playListInfo: playListInfo
				};
				FirebaseService.pushNewItemWithChildKey(Constant.SCHEMA.AUDIO, `${userInfo?.userId}`, data);
			} else {
				let data = {
					userOwnerInfo: {
						id: userInfo?.userId,
						name: userInfo?.name,
						avatar: userInfo?.avatar,
					},
					playListInfo: playListInfo,
					playList: [
						obj
					]
				};
				FirebaseService.pushNewItemWithChildKey(Constant.SCHEMA.AUDIO, `${userInfo?.userId}`, data);
			}
		});
		setSuccess(true);
		ToastHelper.showSuccess('Published your audio successful');
		setTimeout(() => {
			setSuccess(false);
			NavigationService.goBack();
		}, 2000);

	};

	const openImagePicker = () => {
		ImagePicker.showImagePicker(IMAGE_CONFIG, (response) => {
			// console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			} else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			} else {
				const source = {uri: response.uri};
				setUri(source.uri);
				setIsLoading(true);
				Promise.resolve(uploadFileToFireBase(response, userStore.userKey)).then(val => {
					console.log(val);
					setIsLoading(false);
					setUri(val);
				}).catch(() => {
					ToastHelper.showError('Opps. Error while trying upload background audio.');
					setIsLoading(false);
				});
			}
		});
	};

	const pauseOrResumeMusic = async () => {
		if (isPlaying) {
			recordPlayer.pause();
		} else {
			recordPlayer.play((success) => {
				if (success) {
					console.log('successfully finished playing');
					setIsPlaying(false);
				} else {
					console.log('playback failed due to audio decoding errors');
				}
			});
		}
		setIsPlaying(!isPlaying);
	};
	return (
		<View style={[containerStyle.center, {backgroundColor: colors.pinkBackground}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<HeaderWithBackBtn props={props} title="Audio" hasButton onPressRight={() => pickFiles()} rightTitleChildren="Local files" />
				<KeyboardAwareScrollView showsVerticalScrollIndicator={false}>

					<View style={{padding: 20, paddingBottom: 0, paddingTop: 10}}>
						<View style={{flexDirection: 'row'}}>
							<TouchableOpacity onPress={() => openImagePicker()}>
								{!uri ?
									<NoImage /> :
									<FastImage source={{uri: uri}} style={{borderColor: 'white', borderWidth: 4, borderRadius: ScreenWidth / 4, width: ScreenWidth / 4, height: ScreenWidth / 4}} />}
							</TouchableOpacity>
							<View style={{height: ScreenWidth / 4, justifyContent: 'center', paddingLeft: 20}}>
								<TextNormal text={userInfo?.name} style={[containerStyle.textHeaderSmall]} />
								<TextNormal text={`Ranking: #${userInfo?.ranking}`} style={[containerStyle.textDefaultNormal]} />
							</View>
						</View>
						<View style={[containerStyle.defaultMarginTop, containerStyle.defaultMarginBottom]}>
							<TextInputFlat props={props} placeholder="Beginning your stories" text="Title" onChangeText={(text) => setData({...data, title: text})} />
							<View style={{height: ScreenHeight / 4 + 70}}>
								<TextInputFlat multiline={true} style={{height: ScreenHeight / 4 + 70, textAlignVertical: 'top', paddingTop: 0, paddingBottom: 0,}} textInputStyle={{textAlignVertical: 'top', paddingTop: 0, paddingBottom: 0, height: ScreenHeight / 4 + 35, top: 0, left: 0, padding: 5}} onChangeText={(text) => setData({...data, desc: text})} props={props} placeholder="Drop your feel here" text="Tell us your stories" />
							</View>
							<TextInputFlat props={props} placeholder="" value={`${TimeHelper.getTimeDefaultFormatFull(new Date().getTime())}`} text="Today" disabled />
							<TextInputFlat onChangeText={(text) => setData({...data, tags: text})} props={props} placeholder="Back later, of course!" text="Tags" />
						</View>
						{url &&
							<TouchableOpacity style={{height: 40, borderRadius: 20, marginBottom: 20}} onPress={() => { pauseOrResumeMusic(); }}>
								<MusicSpeaker />
								<TouchableOpacity onPress={() => { setIsPlaying(false); recordPlayer?.pause(); setUrl(null); }} style={{position: 'absolute', top: 0, right: '38%'}}>
									<AntDesign name="closecircle" color="red" size={20} />
								</TouchableOpacity>
							</TouchableOpacity>}
						{isPlaying && <Wave style={{height: ScreenWidth * 0.2, width: ScreenWidth * 0.9}} />}
						<View style={[containerStyle.defaultMarginTop, containerStyle.defaultMarginBottom]}>
							<GradientButton text={url ? 'Publish' : 'Start recording'} onPress={() => url ? uploadDB() : start()} />
						</View>
					</View>
				</KeyboardAwareScrollView>
				<ModalWave time={time} isVisible={isVisible} onSuccess={() => {
					stop();
				}} title="Recording" used={(time * 100) / 1800} subTitle="Time limit: 30 minutes" onClose={async () => {
					setTime(0);
					setUrl(null);
					setVisible(false);
					await AudioRecord.stop();
					clearInterval(timeInterval);
				}} />
				{isLoading ? <Loading /> : null}
				{isSuccess ? <CheckDone /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(Recording);
