import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, TouchableOpacity, FlatList, RefreshControl} from 'react-native';
import {styles as style} from './style';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import {NavigationService} from '../../../navigation';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Back from '../../../shared/components/Icons/Back';
import {colors} from '../../../shared/utils/colors/colors';
import {ScreenNames} from '../../../route/ScreenNames';
import icons from '../../../shared/utils/icons/icons';
import AxiosFetcher from '../../../api/AxiosFetch';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import Item from './Item';
import Empty from '../../../shared/components/Empty';
const PigeonMessageScreen = (props) => {
	const {colorsApp} = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const [floatingMessage, setFloatingMsg] = useState([]);
	const [, setFloatingMsgTemp] = useState([]);
	const [currentUser, setCurrentUser] = useState({});
	const [floatingRead] = useState([]);
	const {t} = useTranslation();

	useEffect(() => {
		props?.navigation.addListener('willFocus', () => {
			getFloatingMsg();
		});
		IALocalStorage.getDetailUserInfo().then(async val => {
			let res = val;
			setCurrentUser(res);
			getFloatingMsgRead();
			getFloatingMsg();
		});

	}, [props?.navigation]);

	const getFloatingMsgRead = async () => {
		// FirebaseService.queryAllItemBySchemaWithSpecifiedChild(Constant.SCHEMA.MESSAGESFLOATING, 'M8pfIG0zJwFKQfkHi', true, true)
		// 	.then(val => {
		// 		let res = val;
		// 		setFloatingRead(res);
		// 	})
		// 	.catch(err => {
		// 		setFloatingRead([]);
		// 		ToastHelper.showError(t('error.common'));
		// 	});
	};
	async function getFloatingMsg() {
		setIsLoading(true);
		let userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			url: '/api/useraction/' + userInfoId?.id + '/allFloatingMessage',
			data: undefined,
			hasToken: true,
		}).then(val => {
			if (val) {
				let res = val || [];
				setFloatingMsg(res);

				// Check unread/read
				let arr = [];
				for (let i = 0; i < res.length; i++) {
					let obj = res[i];
					if (floatingRead.indexOf(res[i].id) != -1) {
						obj.read = true;
					} else {
						obj.read = false;
					}
					arr.push(obj);
				}
				setFloatingMsg(arr);
				setFloatingMsgTemp(arr);
			} else {
				setFloatingMsg([]);
			}
			setIsLoading(false);
		}).catch(() => {
			setIsLoading(false);
			ToastHelper.showError('Oops. We tried to get your floating message in being hold but failed.');
		});
	}

	const renderHeader = () => {
		return (
			<View style={style.header}>
				<TouchableOpacity onPress={() => NavigationService.goBack()} style={{flexDirection: 'row'}}>
					<Back props={props} onPress={() => NavigationService.goBack()} style={{marginLeft: 20}} />
				</TouchableOpacity>
				<TextNormal props={props} text={'Pigeon Messages'} style={[containerStyle.textHeader, {color: colors.textBlue, textAlignVertical: 'center'}]} />
				<TouchableOpacity onPress={() => { NavigationService.navigate(ScreenNames.Create); }} style={{flexDirection: 'row', marginEnd: 20}}>
					{icons.IC_PINGEON}
				</TouchableOpacity>
			</View>
		);
	};
	const renderSeparator = () => {
		return (
			<View style={style.separatorView}
			/>
		);
	};
	const renderMessageItem = (item, index) => {
		return (
			<Item
				onItemPress={async () => {
					NavigationService.navigate(ScreenNames.PinMessageScreen, {data: item});
				}}
				item={item}
				index={index}
				isRead={item?.read}
				currentUser={currentUser}
			/>
		);
	};
	return (
		<View style={[{backgroundColor: colors.pinkBackground}]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderHeader()}
				<KeyboardAwareScrollView contentContainerStyle={{backgroundColor: 'white'}} nestedScrollEnabled showsVerticalScrollIndicator={false} refreshControl={
					<RefreshControl refreshing={false} onRefresh={() => getFloatingMsg()} />
				}>

					<View style={[style.container, {backgroundColor: 'white'}]}>
						{floatingMessage?.filter(item => item?.messageType !== 'TEXT')?.length > 0 ?
							<FlatList
								refreshControl={
									<RefreshControl refreshing={false} onRefresh={() => getFloatingMsg()} />
								}
								showsVerticalScrollIndicator={false}
								data={floatingMessage?.filter(item => item?.messageType !== 'TEXT')}
								ItemSeparatorComponent={() => renderSeparator()}
								renderItem={({item, index}) => renderMessageItem(item, index)}
								keyExtractor={(item, index) => index + ''}
								style={{paddingBottom: 200}}
							/> : <Empty />}
					</View>

				</KeyboardAwareScrollView>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(PigeonMessageScreen);
