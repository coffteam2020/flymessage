
import React, { useEffect, useState } from 'react';
import { StatusBar, View, SafeAreaView, TouchableOpacity, Alert } from 'react-native';
import { styles as style, styles } from './style';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { containerStyle } from '../../../themes/styles';
import { useTranslation } from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import DialogInput from 'react-native-dialog-input';
import { NavigationService } from '../../../navigation';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Back from '../../../shared/components/Icons/Back';
import { colors } from '../../../shared/utils/colors/colors';
import { ScreenNames } from '../../../route/ScreenNames';
import AxiosFetcher from '../../../api/AxiosFetch';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import TrackPlayer from 'react-native-track-player';
import { firebase } from '@react-native-firebase/database';
import Constant from '../../../shared/utils/constant/Constant';
import { FlatList } from 'react-native-gesture-handler';
import { ScreenWidth } from '../../../shared/utils/dimension/Divices';
import FastImage from 'react-native-fast-image';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Empty from '../../../shared/components/Empty';
import TextInputFlat from '../../../shared/components/TextInput/TextInputFlat';
import { useStores } from '../../../store/useStore';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import LogManager from '../../../shared/utils/logging/LogManager';
const IMG = 'https://firebasestorage.googleapis.com/v0/b/stayalone-prod.appspot.com/o/blur.jpg?alt=media&token=23d5379e-8c8f-4f0b-8926-59811eeb9ce4';
const Livestream = (props) => {
	const { colorsApp } = props.theme;
	const [isLoading, setIsLoading] = useState(false);
	const [] = useState('');
	const [livestream, setLivestreamRooms] = useState([]);
	const [livestreamT, setLivestreamRoomsT] = useState([]);
	const { userStore } = useStores();
	const [pass, setPass] = useState('');
	const [dialog, showDialog] = useState(false);
	const [tickLivestream, setTickLivestream] = useState(null);

	useEffect(() => {
		TrackPlayer.stop();
		getLivestreamingChannel();
		props?.navigation.addListener('willFocus', () => {
			getInfoItem();
		});
		getInfoItem();
	}, []);

	const getInfoItem = async () => {
		setIsLoading(true);
		const userInfoId = await IALocalStorage.getUserInfo();
		AxiosFetcher({
			method: 'GET',
			data: undefined,
			url: `/api/person/${userInfoId?.id}/itemsuser`,
			hasToken: true,
		})
			.then(async val => {
				setIsLoading(false);
				userStore.setItemsBag(val || []);
			})
			.catch(() => {
				setIsLoading(false);
			});
	};

	const getLivestreamingChannel = async () => {
		firebase.database().ref(Constant.SCHEMA.LIVESTREAM).on('value', snapshot => {
			const data = snapshot.val() || [];
			setLivestreamRooms(Object.values(data));
			setLivestreamRoomsT(Object.values(data));
		});
	};

	const onCreateLivestream = async () => {
		const userInfoId = await IALocalStorage.getUserInfo();
		setIsLoading(true);

		let itemBags = userStore.itemsBag?.slice() || [];
		// if (itemBags?.length === 0) {
		// 	Alert.alert('Opps,', 'You have to buy item Camera or Microphone to able to create new livestreaming', [
		// 		{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen); } },
		// 		{ text: 'Back', onPress: () => { } },
		// 	]);
		// 	setIsLoading(false);
		// } else {
		// 	let shouldMake = false;
		// 	let index = -1;
		// 	for (let i = 0; i < itemBags?.length; i++) {
		// 		if ((itemBags[i]?.itemCode === Constant.CAMERA.itemCode
		// 			|| itemBags[i]?.itemCode === Constant.MICROPHONE.itemCode)
		// 			&& itemBags[i]?.quantity > 0) {
		// 			shouldMake = true;
		// 			index = i;
		// 			break;
		// 		}
		// 	}
		// 	if (shouldMake) {
		// 		AxiosFetcher({
		// 			method: 'POST',
		// 			url: `/api/useraction/${userInfoId?.id}/useItem/${itemBags?.[index]?.itemType}`,
		// 			hasToken: true,
		// 		}).then(val => {
		// 			setIsLoading(false);
		NavigationService.navigate(ScreenNames.InformationRoom);
		// 		}).catch(err => {
		// 			setIsLoading(false);
		// 			ToastHelper.showError(err?.message || 'Could not create your room. Try again later')
		// 		})

		// 	} else {
		// 		setIsLoading(false);
		// 		Alert.alert('Opps,', 'You have to buy item Camera or Microphone to able to create new livestreaming', [
		// 			{ text: 'Let me buy', onPress: () => { NavigationService.navigate(ScreenNames.StoreScreen, {highlight: [Constant.CAMERA.itemCode, Constant.MICROPHONE.itemCode]}); } },
		// 			{ text: 'Back', onPress: () => { } },
		// 		]);
		// 	}
		// }
	};

	const renderHeader = () => {

		const hide = livestream?.filter(a => a.ownerUserId?.id === userStore.userInfo.userId).length > 0;
		return (
			<View>
				<View style={style.header}>
					<TouchableOpacity onPress={() => NavigationService.goBack()} style={{ flexDirection: 'row' }}>
						<Back props={props} onPress={() => NavigationService.goBack()} style={{ marginLeft: 15 }} />
					</TouchableOpacity>
					<TextNormal props={props} text={'Live stream'} style={[containerStyle.textHeader, { color: colors.textBlue, textAlignVertical: 'center' }]} />

					<TouchableOpacity onPress={hide ? () => { } : () => { onCreateLivestream(); }} style={{ flexDirection: 'row', marginEnd: 10, padding: 5 }}>
						{hide ? null : <TextNormal props={props} text={'Go live'} style={[containerStyle.textContent, { color: colors.textBlue, textAlignVertical: 'center' }]} />}
					</TouchableOpacity>
				</View>
			</View>
		);
	};

	const onJoinLivestream = async (curLiveStream) => {
		setTickLivestream(curLiveStream);
		let user = await IALocalStorage.getDetailUserInfo();

		// if (curLiveStream?.status === 'END') {
		// 	alert('This livestreaming is end');
		// 	return;
		// }
		if (curLiveStream?.ownerUserId?.id !== user?.userId && curLiveStream?.password && curLiveStream?.password != '') {
			showDialog(true);
			return;
		}
		NavigationService.navigate(ScreenNames.VideoCallScreen, { curLiveStream: curLiveStream });

	};

	const renderItem = (item, index) => {

		let channelName = item?.channelName?.split('_')[0];
		let tags = '';
		(item?.tags || []).forEach(element => {
			tags = tags + element + '\n';
		});
		tags = tags?.substring(0, tags.lastIndexOf('\n'));

		// Rating by ranking and participiants
		let rateCount = item?.ownerUserId?.rate || 0;
		rateCount += item?.participiants?.length || 0;
		let color = 'rgba(256,256,0,' + (rateCount === 0 ? '0.6' : rateCount < 20 ? '0.8' : rateCount < 50 ? '0.8' : '1') + ')';
		return (
			<TouchableOpacity onPress={() => {
				Alert.alert('Hi', 'Do you want to view or continue joining your room?', [
					{
						text: 'View my room',
						onPress: () => {
							NavigationService.navigate(ScreenNames.InformationRoom, {item: item});
						}
					},
					{
						text: 'Join me',
						onPress: () => {
							onJoinLivestream(item);
						}
					},
					{
						text: 'Cancel',
						onPress: () => {}
					}
				])
				
			}} style={[styles.item, { marginLeft: index % 2 === 0 ? 3 : -5 }]}>
				<FastImage
					source={{ uri: item?.ownerUserId?.avatar || IMG }}
					style={{ height: (ScreenWidth - 30) / 3, width: (ScreenWidth - 30) / 2, borderRadius: 15 }}
					resizeMethod="resize"
					cache={FastImage.cacheControl.immutable}
					resizeMode="cover" />
				{item?.participiants?.length === 0 ? <View style={styles.count}>
					<Ionicons name="ios-eye" size={20} color={'white'} />
					<TextNormal text={` ${item?.status === 'END' ? 0 : (item?.participiants?.length || 0)}`} style={[containerStyle.textDefault, { color: colors.whiteBackground }]} />
				</View> : null}
				<View style={styles.rate}>
					<MaterialCommunityIcons name="star-face" size={20} color={color} />
					{rateCount >= 20 && <MaterialCommunityIcons name="star-face" size={20} color={color} />}
					{rateCount >= 50 && <MaterialCommunityIcons name="star-face" size={20} color={color} />}
				</View>
				<View style={[styles.id]}>
					<TextNormal numberOfLines={1} text={`#${item?.uid}`} style={[containerStyle.textContentSmall, { color: colors.whiteBackground }]} />
				</View>
				<View style={styles.livestreamItem}>
					<TextNormal numberOfLines={3} text={`${channelName}`} style={[containerStyle.textHeader, { color: colors.whiteBackground }]} />
					<TextNormal numberOfLines={3} text={`${item?.ownerUserId?.name || ''} `} style={[containerStyle.textDefault, { color: colors.whiteBackground }]} />
					{item?.tags && item?.tags?.length > 0 ? <TextNormal numberOfLines={3} text={tags || ''} style={[containerStyle.textContentSmall, { color: colors.whiteBackground, width: ScreenWidth * 0.25 }]} /> :
						<TextNormal numberOfLines={3} text={item?.ownerUserId?.address || ''} style={[containerStyle.textContentSmall, { color: colors.whiteBackground }]} />}
				</View>
			</TouchableOpacity>
		);
	};

	return (
		<View style={[{ backgroundColor: colors.pinkBackground }]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderHeader()}
				<KeyboardAwareScrollView
					nestedScrollEnabled
					showsVerticalScrollIndicator={false}
					contentContainerStyle={{ marginTop: 0, height: '100%', paddingBottom: 100 }}>
					{<TextInputFlat onChangeText={(text) => {
						if (text?.trim() === '') {
							setLivestreamRooms(livestreamT);
						} else {
							let arr = [];
							for (let i = 0; i < livestreamT?.length; i++) {
								const isGot = false;
								for (let k = 0; k < livestreamT[i]?.tags?.length; k++) {
									if (livestreamT[i]?.tags[k]?.includes(text?.toLowerCase())) {
										isGot = true;
										break;
									}
								}
								if (livestreamT[i]?.ownerUserId?.name?.toLowerCase().includes(text?.toLowerCase()) ||
									text?.toLowerCase().includes(livestreamT[i]?.uid) || `${livestreamT[i]?.uid}`?.toLowerCase().includes(text) ||
									livestreamT[i]?.ownerUserId?.name?.toLowerCase().includes(text?.toLowerCase()) ||
									livestreamT[i]?.tags?.includes(`#${text?.toLowerCase()}`) ||
									isGot ||
									livestreamT[i]?.channelName?.toLowerCase().includes(text?.toLowerCase())) {
									arr?.push(livestreamT[i]);
								}
							}
							setLivestreamRooms(arr);
						}
					}} props={props} style={{ width: '90%', alignSelf: 'center', marginBottom: 20 }} placeholder="Search channel by id, name, tags ..." />}
					{livestream?.length === 0 ?
						<Empty /> :
						<FlatList
							numColumns={2}
							showsVerticalScrollIndicator={false}
							data={livestream}
							renderItem={({ item, index }) => renderItem(item, index)}
							keyExtractor={(item, index) => index + ''}
						/>}
				</KeyboardAwareScrollView>
				<DialogInput isDialogVisible={dialog}
					title={'This room is private.'}
					message={'Enter a password to jump in'}
					hintInput={'Room`s password'}
					submitInput={(inputText) => {
						showDialog(false);
						if (inputText === tickLivestream?.password) {
							NavigationService.navigate(ScreenNames.VideoCallScreen, { curLiveStream: tickLivestream });
						} else {
							ToastHelper.showError('You inputted wrong password for this room');
						}
					}}
					closeDialog={() => {
						showDialog(false);
					}}>
				</DialogInput>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	);
};

export default withTheme(Livestream);
