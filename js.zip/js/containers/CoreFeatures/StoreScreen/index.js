import { useObserver } from 'mobx-react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SafeAreaView, ScrollView, StatusBar, TouchableOpacity, View, Platform } from 'react-native';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { colors } from '../../../shared/utils/colors/colors';
import { ScreenWidth, ScreenHeight } from '../../../shared/utils/dimension/Divices';
import { useStores } from '../../../store/useStore';
import { containerStyle } from '../../../themes/styles';
import { styles } from './style';
import HeaderWithBackBtn from '../../../shared/components/Header/HeaderWithBackBtn';
import LogManager from '../../../shared/utils/logging/LogManager';
import IALocalStorage from '../../../shared/utils/storage/IALocalStorage';
import AxiosFetcher from '../../../api/AxiosFetch';
import { ToastHelper } from '../../../shared/components/ToastHelper';
import Loading from '../../../shared/components/Loading';
import ImageAvtRectRounded from '../../../shared/components/Avatar/ImageAvtRectRounded';
import Constant from '../../../shared/utils/constant/Constant';
import * as RNIap from 'react-native-iap';
import Empty from '../../../shared/components/Empty';
import * as Animatable from 'react-native-animatable';
import { useNavigationParam } from 'react-navigation-hooks';

const itemSkus = Platform.select({
	ios: [
		'air_plane',
	],
	android: [
		'air_plane',
		// 'android.test.canceled',
		// 'android.test.refunded',
		// 'android.test.item_unavailable',
	],
});

const StoreScreen = (props) => {
	const { colorsApp } = props.theme;
	const [currentIndex, setCurrentIndex] = useState(0);
	const [isLoading, setIsLoading] = useState(false);
	const [products, setProducts] = useState([]);
	const highlight = useNavigationParam('highlight');
	const { t } = useTranslation();
	const { userStore } = useStores();

	useEffect(() => {
		getStore();
		getProducts();
	}, []);

	const getProducts = async () => {
		try {
			const result = await RNIap.initConnection();
			console.log('result', result);
			const products: RNIap.Product[] =
				await RNIap.getProducts(itemSkus);
			// let result1 = await RNIap.consumeAllItemsAndroid();
			// console.log('result', result1);
			//   console.log('result', result);			
			console.log(LogManager.parseJsonObjectToJsonString(products));
		} catch (err) {
			console.log(err);
			ToastHelper.showError('Oops. We tried to get list item products but failed. Please try again');
		}
	};

	const getStore = async () => {
		const token = await IALocalStorage.getTokenUserInfo();
		setIsLoading(true);
		AxiosFetcher({
			method: 'POST',
			data: undefined,
			url: '/api/items/allPagination?limit=100&offset=0&sortBy=itemName',
			hasToken: true,
			token: token
		})
			.then(async val => {
				setIsLoading(false);
				userStore.setItems(val && val.content);
			})
			.catch(err => {
				setIsLoading(false);
				ToastHelper.showError('Oops. We tried to get list item stores but failed. Please try again');
			});
	};

	const renderTopHeader = () => {
		return (
			<HeaderWithBackBtn props={props} title="Store" />
		);
	};

	const renderItems = () => {
		const items = userStore?.items && userStore?.items?.filter(item => !item.salable && !item.deleted) || [];
		if (items?.length === 0) {
			return (
				<Empty />
			);
		}
		return (
			items.map(item => {
				const { attachmentImageUrl, itemName, price, itemDescription } = item;
				return (
					<>
						{renderItem(attachmentImageUrl, itemName, `$${price}`, itemDescription, () => { }, item)}
					</>
				);
			}));
	};
	const renderItemsSpecial = () => {
		const items = userStore.items.filter(item => item.salable && !item.deleted);
		if (items?.length === 0) {
			return (
				<Empty />
			);
		}
		return (
			items.map(item => {
				const { attachmentImageUrl, itemName, price, itemDescription } = item;
				return (
					<>
						{renderItem(attachmentImageUrl, itemName, `$${price}`, itemDescription, () => { }, item)}
					</>
				);
			}));
	};

	const renderItem = (ico, name, price, desc, onPress, item) => {
		console.log(highlight);
		console.log(item?.itemName);
		console.log(item?.itemCode);
		console.log(highlight?.indexOf(item?.itemCode));
		return (
			<TouchableOpacity onPress={async () => {
				// setIsLoading(true);
				// try {
				// 	await RNIap.getAvailablePurchases();
				// } catch (error) {
				// 	setIsLoading(false);
				// }

				// await RNIap.requestSubscription('air_plane').then(async val => {
				setIsLoading(true);
				let userInfo = await IALocalStorage.getDetailUserInfo();
				AxiosFetcher({
					method: 'POST',
					data: {
						'amount': 1.99,
						'itemCode': item?.itemCode,
						'quantity': 1,
						'status': 'string',
						'transactionType': 'PURCHASED',
						'userId': userInfo?.userId
					},
					url: '/api/transaction/create',
					hasToken: true,
				})
					.then(async val => {
						setIsLoading(false);
						ToastHelper.showSuccess('You have purchased successfully ' + name);
						// AxiosFetcher({
						// 	method: 'POST',
						// 	url: `/api/${userInfo?.userId}/useItem/${item?.itemType || item?.type}`,
						// 	hasToken: true,
						// });
					})
					.catch(err => {
						setIsLoading(false);
						ToastHelper.showError('Oops. We tried to get purchase item stores but itunes issued. Please try again');
					});
				// }).catch(error => {
				// 	setIsLoading(false);
				// 	console.log(LogManager.parseJsonObjectToJsonString(error));
				// 	ToastHelper.showError(error?.message);
				// }).finally(()=>{
				// 	setIsLoading(false);
				// })


			}
			}
				style={[containerStyle.horContainer, styles.item, { backgroundColor: highlight && highlight?.indexOf(item?.itemCode) !== -1 ? colors.green : colors.whiteBackground }]}>
				<Animatable.View
					animation={highlight && highlight?.indexOf(item?.itemCode) !== -1 ? "shake" : ""}
					iterationDelay={1000}
					iterationCount={highlight && highlight?.indexOf(item?.itemCode) !== -1 ? "infinite" : 0}
					style={[containerStyle.horContainer, {
						paddingStart: 40,
						paddingEnd: 40,
						alignSelf: 'flex-start',
						alignItems: 'flex-start'
					}]}>
					<View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
						<ImageAvtRectRounded
							style={[containerStyle.avatarRectRoundedStoreDefault]}
							uri={ico || Constant.MOCKING_DATA.PLACE_HOLDER} />
						<View style={{ marginLeft: 10 }}>
							<TextNormal props={props} text={`${name}`} style={[styles.textDefaultHeader, { width: ScreenWidth / 3 }]} />
							<TextNormal props={props} text={''} style={[containerStyle.textContentSmall]} />
							<TextNormal numberOfLines={5} props={props} text={desc}
								style={[styles.textContentSmall, { width: ScreenWidth - 100 }]} />
						</View>
					</View>
					<TextNormal props={props} text={'$1.99'} style={[styles.textDefaultHeader]} />
				</Animatable.View>
			</TouchableOpacity>
		);
	};

	const renderTabbar = () => {
		return (
			<View style={[containerStyle.horContainer, containerStyle.shadow, {
				height: ScreenHeight / 10,
				backgroundColor: colors.whiteBackground,
				width: ScreenWidth,
			}]}>
				<TouchableOpacity onPress={() => {
					setCurrentIndex(0);
				}}
					style={[styles.btn, currentIndex !== 0 ? { backgroundColor: colors.gray } : containerStyle.defaultBackground]}>
					<TextNormal text="Feature items" style={{ color: currentIndex === 0 ? 'white' : 'black' }} />
				</TouchableOpacity>
				<TouchableOpacity onPress={() => {
					setCurrentIndex(1);
				}}
					style={[styles.btn, currentIndex !== 1 ? { backgroundColor: colors.gray } : containerStyle.defaultBackground]}>
					<TextNormal text="Special items" style={{ color: currentIndex === 1 ? 'white' : 'black' }} />
				</TouchableOpacity>
			</View>
		);
	};
	return useObserver(() => (
		<View style={[containerStyle.default]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				{renderTopHeader()}
				<View style={styles.content}>
					{renderTabbar()}
					<ScrollView nestedScrollEnabled contentContainerStyle={{ paddingBottom: 200 }}>
						{currentIndex === 0 ? renderItems() : renderItemsSpecial()}
					</ScrollView>
				</View>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>
		</View>
	));
};

export default withTheme(StoreScreen);
