import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView} from 'react-native';
import {styles as style} from './style';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import {containerStyle} from '../../../themes/styles';
import {useTranslation} from 'react-i18next';
import {ToastHelper} from '../../../shared/components/ToastHelper';
import Loading from '../../../shared/components/Loading';
import {NavigationService} from '../../../navigation';
import {GoogleSignin} from '@react-native-community/google-signin';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Constant from '../../../shared/utils/constant/Constant';
import {ImageBackground} from 'react-native';
import {images} from '../../../../assets';
import Back from '../../../shared/components/Icons/Back';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import {useNavigationParam} from 'react-navigation-hooks';
import {ScreenNames} from '../../../route/ScreenNames';
import AxiosFetcher from '../../../api/AxiosFetch';
import LogManager from '../../../shared/utils/logging/LogManager';


const OTPVerifyScreen = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const [isLoading, setIsLoading] = useState(false);
	const phoneNumber = useNavigationParam('phoneNumber');
	let confirmResult = useNavigationParam('confirmResult');
	let isResetPass = useNavigationParam('isResetPass');
	let data = useNavigationParam('data');
	useEffect(() => {
		GoogleSignin.configure({
			webClientId: Constant.WEB_CLIENT_ID
		});
	}, []);

	const register = () => {
		setIsLoading(true);
		AxiosFetcher({
			method: 'POST',
			url: '/api/auth/signup',
			data: {
				password: data?.password,
				phoneNumber: data?.phoneNumber?.replace(/ /g, ''),
			}
		}).then(data => {
			setIsLoading(false);
			if (data && data?.accessToken != '') {
				ToastHelper.showSuccess(t('signUp.signUpDone'));
				NavigationService.navigate(ScreenNames.LoginScreen);
			} else {
				console.log(LogManager.parseJsonObjectToJsonString(data));
				ToastHelper.showError(data?.message || 'The phone number is existed');
			}
		})
			.catch((err) => {
				console.log(LogManager.parseJsonObjectToJsonString(err));
				ToastHelper.showError( err?.data?.message || 'The phone number is existed');
				setIsLoading(false);
			})
			.finally(() => {
				setIsLoading(false);
			});
	};
	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<ImageBackground source={images.bgNormal} style={{width: '100%', height: '100%'}}>
				<SafeAreaView>
					<KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
						<View style={style.content}>
							<Back props={props} onPress={() => NavigationService.goBack()} />
							<View style={style.container}>
								<TextNormal numberOfLines={2} props={props} text={t('verify.name')} style={[containerStyle.textHeaderWithMargin, containerStyle.defaultMarginBottom]} />
								<View style={style.fieldContainer}>
									<TextNormal numberOfLines={2} style={{width: '90%'}} props={props} text={`${t('verify.motto')}`} />
									<TextNormal numberOfLines={2} props={props} style={[containerStyle.textHeaderSmall, containerStyle.defaultMarginTop]} text={` ${phoneNumber ?? '+84963226782'}`} />
									<OTPInputView
										style={{width: '90%', height: 200}}
										pinCount={6}
										autoFocusOnLoad
										codeInputFieldStyle={style.underlineStyleBase}
										codeInputHighlightStyle={style.underlineStyleHighLighted}
										onCodeFilled={(code => {
											if (confirmResult) {
												confirmResult?.confirm(code)
													.then(() => {
														if (isResetPass && isResetPass) {
															NavigationService.navigate(ScreenNames.ResetPassScreen, {phoneNumber: phoneNumber});
														} else {
															register();
														}
													})
													.catch((error) => {
														ToastHelper.showError(error?.message || t('error.common'));
													});
											}
										})}
									/>
								</View>
							</View>
						</View>
					</KeyboardAwareScrollView>
					{isLoading ? <Loading /> : null}
				</SafeAreaView>
			</ImageBackground>
		</View>
	);
};

export default withTheme(OTPVerifyScreen);
