import React, { useEffect, useState } from 'react';
import { StatusBar, View, SafeAreaView } from 'react-native';
import { styles as style } from './style';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../../shared/components/Text/TextNormal';
import { containerStyle } from '../../../themes/styles';
import { useTranslation } from 'react-i18next';
import Loading from '../../../shared/components/Loading';
import { NavigationService } from '../../../navigation';
import { GoogleSignin } from '@react-native-community/google-signin';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Constant from '../../../shared/utils/constant/Constant';
import { ImageBackground } from 'react-native';
import { images } from '../../../../assets';
import Back from '../../../shared/components/Icons/Back';
import { useNavigationParam } from 'react-navigation-hooks';
import { colors } from '../../../shared/utils/colors/colors';
import TextPhoneInput from '../../../shared/components/TextInput/TextPhoneInput';
import GradientButton from '../../../shared/components/Buttons/GradientButton';
import {firebase} from '@react-native-firebase/auth';
import { ScreenNames } from '../../../route/ScreenNames';
import { ToastHelper } from '../../../shared/components/ToastHelper';


const ResetScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	const [isLoading] = useState(false);
	const [phone, setPhone] = useState('');
	const phoneNumber = useNavigationParam('phoneNumber');
	useEffect(() => {
		GoogleSignin.configure({
			webClientId: Constant.WEB_CLIENT_ID
		});

		// }
	}, []);
	const verifyPhone = () => {
		firebase.auth().signInWithPhoneNumber(phone)
			.then(confirmResult => {
				NavigationService.navigate(ScreenNames.OTPVerifyScreen, { isResetPass: true, phoneNumber: phone, confirmResult: confirmResult });
			})
			.catch(error => {
				ToastHelper.showError(error.message);
			});
	};
	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<ImageBackground source={images.bgNormal} style={{ width: '100%', height: '100%' }}>
				<SafeAreaView>
					<KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
						<View style={style.content}>
							<Back props={props} onPress={() => NavigationService.goBack()} />
							<View style={style.container}>
								<TextNormal numberOfLines={2} props={props} text={t('reset.name')} style={[containerStyle.textHeaderWithMargin, containerStyle.defaultMarginBottom]} />
								<View style={style.fieldContainer}>
									<TextNormal style={containerStyle.defaultMarginBottom} numberOfLines={2} props={props} text={`${t('reset.motto')}`} />
									<TextPhoneInput keyboardType={'number-pad'} onChangeText={(text) => setPhone(text)} text={t('register.emergency')} props={props} backgroundColor={colorsApp.backgroundInput} borderColor={colorsApp.borderColor} cancelText={t('common.cancel')} confirmText={t('common.confirm')} />
									<GradientButton onPress={() => { verifyPhone() }} text={t('reset.change')} style={containerStyle.defaultMarginTop} />
								</View>
							</View>
						</View>
					</KeyboardAwareScrollView>
					{isLoading ? <Loading /> : null}
				</SafeAreaView>
			</ImageBackground>
		</View>
	);
};

export default withTheme(ResetScreen);
