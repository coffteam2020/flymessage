import React, { useEffect, useState } from "react";
import { StatusBar, View, SafeAreaView } from "react-native";
import { styles } from "./style";
import { withTheme } from "react-native-paper";
import TextNormal from "../../shared/components/Text/TextNormal";
import { containerStyle } from "../../themes/styles";
import { useTranslation } from 'react-i18next';
import { textStyleDefaultHeader, textStyleDefaultRegular } from "../../themes/text";
import GradientButton from "../../shared/components/Buttons/GradientButton";
import icons from "../../shared/utils/icons/icons";
import { NavigationService } from "../../navigation";
import { ScreenNames } from "../../route/ScreenNames";


const ChangePassDoneScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	useEffect(() => {
	}, [])

	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<View style={styles.content}>
					<View style={styles.container}>
						{icons.IC_SUCCESS}
						<TextNormal numberOfLines={2} props={props} text={t("reset.congrat")} style={[textStyleDefaultHeader, styles.motto]} />
						<TextNormal numberOfLines={2} props={props} text={t("reset.mottoCongrat")} style={[textStyleDefaultRegular, styles.mottoEmail]} />
						<GradientButton onPress={() => NavigationService.navigate(ScreenNames.LoginScreen)} text={t("reset.loginNow")} style={styles.button} />
					</View>
				</View>
			</SafeAreaView>

		</View>
	);
}

export default withTheme(ChangePassDoneScreen);
