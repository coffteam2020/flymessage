import React, {useEffect, useState} from 'react';
import {StatusBar, View, SafeAreaView, TouchableOpacity, Keyboard} from 'react-native';
import {styles} from './style';
import {withTheme} from 'react-native-paper';
import TextNormal from '../../shared/components/Text/TextNormal';
import {containerStyle} from '../../themes/styles';
import {useTranslation} from 'react-i18next';
import Back from '../../shared/components/Icons/Back';
import {textStyleDefaultHeader} from '../../themes/text';
import GradientButton from '../../shared/components/Buttons/GradientButton';
import {ToastHelper} from '../../shared/components/ToastHelper';
import Loading from '../../shared/components/Loading';
import {NavigationService} from '../../navigation';
import {ScreenNames} from '../../route/ScreenNames';
import OTPInput from '../../shared/components/OTPInput/OTPInput';
import {firebase} from '@react-native-firebase/database';
import {useStores} from '../../store/useStore';

const VerifyScreen = (props) => {
	const {colorsApp} = props.theme;
	const {t} = useTranslation();
	const {userStore} = useStores();
	const [code, setCode] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const onCodeChange = text => {
		setCode(text);
	};
	const [confirmResult, setConfirmResult] = useState(null);
	const onVerify = () => {
		Keyboard.dismiss();
		setIsLoading(true);
		if (code.length < 6) {
			ToastHelper.showError(t('verify.invalid'));
			setIsLoading(false);
		} else {
			onVerifyOTP();
		}
	};
	const onVerifyPhone = async () => {
		if (userStore?.userRegisterBeing?.phone) {
			firebase.auth().signInWithPhoneNumber(userStore.userRegisterBeing.phone)
				.then(confirmResult => {
					setConfirmResult(confirmResult);
				})
				.catch(() => {
					ToastHelper.showError('Oops. We tried to verifying your information but failed. You can login yourself and continue enjoy');
				});
		} else {
			ToastHelper.showError('Oops. We tried to verifying your information but failed. You can login yourself and continue enjoy');
		}
	};
	const onVerifyOTP = async () => {
		if (confirmResult) {
			confirmResult
				.confirm(code)
				.then(async () => {
					setIsLoading(false);
					ToastHelper.showSuccess(t('signUp.success'));
					NavigationService.navigate(ScreenNames.IntroNameScreen);
				})
				.catch(() => {
					setIsLoading(false);
					ToastHelper.showError('Oops. We tried to verifying your phone but failed. You can login yourself and continue enjoy');
				});
		} else {
			setIsLoading(false);
			ToastHelper.showError('Oops. We tried to verifying your phone but failed. You can login yourself and continue enjoy');
		}
	};
	useEffect(() => {
		onVerifyPhone();
	}, []);

	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<SafeAreaView>
				<View style={styles.content}>
					<Back props={props} />
					<View style={styles.container}>
						<TextNormal props={props} text={t('verify.name')} style={[textStyleDefaultHeader, styles.motto]} />
						<TextNormal numberOfLines={2} props={props} text={t('verify.motto')} style={styles.mottoEmail} />
						<OTPInput
							textColor={colorsApp.textColor}
							value={code}
							onChangeText={text => { onCodeChange(text); }}
							otpLength={6}
						/>
						<TouchableOpacity onPress={() => { }} style={[containerStyle.horContainerNearly, styles.container]}>
							<TextNormal numberOfLines={2} props={props} text={t('verify.resend')} style={styles.mottoEmail} />
							<TextNormal numberOfLines={2} props={props} text={t('verify.resendMotto')} style={[styles.mottoEmail, styles.verify]} />
						</TouchableOpacity>
						<GradientButton onPress={() => onVerify()} text={t('verify.verify')} style={styles.button} />
					</View>
				</View>
				{isLoading ? <Loading /> : null}
			</SafeAreaView>

		</View>
	);
};

export default withTheme(VerifyScreen);
