import React, { useEffect, useState } from 'react';
import { StatusBar, View, SafeAreaView, ImageBackground } from 'react-native';
import { styles } from './style';
import { withTheme } from 'react-native-paper';
import TextNormal from '../../shared/components/Text/TextNormal';
import { containerStyle } from '../../themes/styles';
import { useTranslation } from 'react-i18next';
import Back from '../../shared/components/Icons/Back';
import { textStyleDefaultHeader } from '../../themes/text';
import TextInputFlat from '../../shared/components/TextInput/TextInputFlat';
import { colors } from '../../shared/utils/colors/colors';
import GradientButton from '../../shared/components/Buttons/GradientButton';
import Validator from '../../shared/utils/validator/Validator';
import { ToastHelper } from '../../shared/components/ToastHelper';
import Loading from '../../shared/components/Loading';
import Eye from '../../shared/components/Icons/Eye';
import { NavigationService } from '../../navigation';
import { ScreenNames } from '../../route/ScreenNames';
import { images } from '../../../assets';
import { useNavigationParam } from 'react-navigation-hooks';
import AxiosFetcher from '../../api/AxiosFetch';
import CheckDone from '../../shared/components/CheckDone';


const ResetPassScreen = (props) => {
	const { colorsApp } = props.theme;
	const { t } = useTranslation();
	const [password, setPassword] = useState('');
	const [showPassword, setShowPassword] = useState(true);
	const [confirmPassword, setConfirmPassword] = useState('');
	const [showConfirmPassword, setShowConfirmPassword] = useState(true);
	const [isLoading, setIsLoading] = useState(false);
	const [isSuccess, setIsSuccess] = useState(false);
	let phoneNumber = useNavigationParam('phoneNumber');
	const onPassChange = text => {
		setPassword(text);
	};
	const onConfirmPassChange = text => {
		setConfirmPassword(text);
	};
	const onConfirm = () => {
		setIsLoading(true);
		if (Validator.checkEmptyField(password) || Validator.checkEmptyField(confirmPassword)) {
			setIsLoading(false);
			ToastHelper.showError(t('error.empty'));
		} else {
			if (password !== confirmPassword) {
				setIsLoading(false);
				ToastHelper.showError(t('reset.notMatch'));
			} else {
				setIsLoading(true);
				AxiosFetcher({
					method: 'POST',
					url: '/api/auth/updatePassword',
					data: {
						phoneNumber: phoneNumber.replace(/ /g, ''),
						newPassword: password
					}
				}).then(async val => {
					setIsLoading(false);
					setIsSuccess(true);
					setTimeout(()=>{
						ToastHelper.showSuccess(t('reset.mottoCongrat'));
						NavigationService.navigate(ScreenNames.LoginScreen);		
					}, 1000);
				})
					.catch(() => {
						setIsLoading(false);
						ToastHelper.showError('Oops. We tried to change your information but failed. Try again please');
					});
			}
		}
	};
	useEffect(() => {

	}, []);

	return (
		<View style={[containerStyle.center]}>
			<StatusBar barStyle={colorsApp.statusBar} />
			<ImageBackground source={images.bgNormal} style={{ width: '100%', height: '100%' }}>
				<SafeAreaView>
					<View style={styles.content}>
						<Back props={props} />
						<View style={styles.container}>
							<TextNormal props={props} text={t('reset.name')} style={[textStyleDefaultHeader, styles.motto]} />
							<TextNormal numberOfLines={2} props={props} text={t('reset.motto')} style={styles.mottoEmail} />
							<TextInputFlat onChangeText={(text) => onPassChange(text)} text={t('reset.password')} props={props} onPressIco={() => { setShowPassword(!showPassword); }} secureText={showPassword} hasRightIco ico={<Eye isOff={!showPassword} color={colors.iconGreen} />} />
							<TextInputFlat onChangeText={(text) => onConfirmPassChange(text)} text={t('reset.confirmPassword')} onPressIco={() => { setShowConfirmPassword(!showConfirmPassword); }} secureText={showConfirmPassword} props={props} hasRightIco ico={<Eye isOff={!showConfirmPassword} color={colors.iconGreen} />} />
							<GradientButton onPress={() => onConfirm()} text={t('reset.change')} style={styles.button} />
						</View>
					</View>
					{isLoading ? <Loading /> : null}
					{isSuccess ? <CheckDone /> : null}
				</SafeAreaView>
			</ImageBackground>
		</View>
	);
};

export default withTheme(ResetPassScreen);
