/* eslint-disable no-unused-vars */
import {firebase} from '@react-native-firebase/messaging';
export default async (message) => {
	// handle your message

	return Promise.resolve();
};